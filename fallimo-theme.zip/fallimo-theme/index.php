<?php
/**
 * The main template file
 *
 * @package Fallimo
 */

get_header();
?>

<main id="primary" class="site-main">
    <?php
    if (have_posts()) :
        while (have_posts()) :
            the_post();
            the_content();
        endwhile;
    else :
        ?>
        <div class="container" style="padding: 4rem 1rem; text-align: center;">
            <h1><?php _e('Nothing Found', 'fallimo'); ?></h1>
            <p><?php _e('It seems we can\'t find what you\'re looking for.', 'fallimo'); ?></p>
        </div>
        <?php
    endif;
    ?>
</main>

<?php
get_footer();
