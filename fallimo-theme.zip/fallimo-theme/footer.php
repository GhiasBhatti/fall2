    <?php if (!is_page_template('elementor-canvas.php')) : ?>
    <footer id="colophon" class="site-footer">
        <div class="container">
            <div class="footer-content">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'footer',
                    'menu_id'        => 'footer-menu',
                    'fallback_cb'    => false,
                ));
                ?>
                <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. <?php _e('All rights reserved.', 'fallimo'); ?></p>
            </div>
        </div>
    </footer>
    <?php endif; ?>

</div>

<?php wp_footer(); ?>

</body>
</html>
