<?php
/**
 * Auto Import Functionality
 * Creates default pages with Elementor content on theme activation
 */

if (!defined('ABSPATH')) exit;

/**
 * Run auto-import on theme activation
 */
function fallimo_auto_import() {
    // Check if already imported
    if (get_option('fallimo_auto_import_done')) {
        return;
    }
    
    // Ensure Elementor is active
    if (!did_action('elementor/loaded')) {
        return;
    }
    
    // Create homepage with Elementor
    $homepage_id = fallimo_create_homepage();
    
    // Create fleet page
    $fleet_page_id = fallimo_create_fleet_page();
    
    // Create services page
    $services_page_id = fallimo_create_services_page();
    
    // Create reviews page
    $reviews_page_id = fallimo_create_reviews_page();
    
    // Set homepage as front page
    if ($homepage_id) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $homepage_id);
    }
    
    // Create primary menu
    fallimo_create_default_menu($homepage_id, $fleet_page_id, $services_page_id, $reviews_page_id);
    
    // Configure Elementor settings
    fallimo_configure_elementor();
    
    // Mark as imported
    update_option('fallimo_auto_import_done', true);
}
add_action('after_switch_theme', 'fallimo_auto_import');

/**
 * Create Homepage
 */
function fallimo_create_homepage() {
    $page_id = wp_insert_post([
        'post_title'   => 'Home',
        'post_content' => '',
        'post_status'  => 'publish',
        'post_type'    => 'page',
        'post_name'    => 'home'
    ]);
    
    if (!$page_id) return false;
    
    // Enable Elementor
    update_post_meta($page_id, '_elementor_edit_mode', 'builder');
    update_post_meta($page_id, '_elementor_template_type', 'wp-page');
    update_post_meta($page_id, '_wp_page_template', 'elementor-canvas.php');
    
    // Set Elementor data - Pre-built page structure
    $elementor_data = [
        [
            'id' => fallimo_generate_id(),
            'elType' => 'section',
            'settings' => [],
            'elements' => [
                [
                    'id' => fallimo_generate_id(),
                    'elType' => 'column',
                    'settings' => ['_column_size' => 100],
                    'elements' => [
                        [
                            'id' => fallimo_generate_id(),
                            'elType' => 'widget',
                            'widgetType' => 'fallimo_hero',
                            'settings' => [
                                'title' => 'Number #1 Party Bus and Limo Service',
                                'subtitle' => 'Choose the Best, Leave the Rest!',
                                'description' => 'Make your Event Unforgettable with our Top-Rated Service. Luxury party bus and limousine rental service across NJ, NY, CT & Philadelphia area.',
                                'primary_button_text' => 'Get Free Quote',
                                'primary_button_link' => '#quote',
                                'secondary_button_text' => 'View Fleet',
                                'secondary_button_link' => '#fleet',
                            ]
                        ]
                    ]
                ]
            ]
        ],
        [
            'id' => fallimo_generate_id(),
            'elType' => 'section',
            'settings' => [],
            'elements' => [
                [
                    'id' => fallimo_generate_id(),
                    'elType' => 'column',
                    'settings' => ['_column_size' => 100],
                    'elements' => [
                        [
                            'id' => fallimo_generate_id(),
                            'elType' => 'widget',
                            'widgetType' => 'fallimo_fleet',
                            'settings' => [
                                'section_title' => 'Our Premium Fleet',
                            ]
                        ]
                    ]
                ]
            ]
        ],
        [
            'id' => fallimo_generate_id(),
            'elType' => 'section',
            'settings' => [],
            'elements' => [
                [
                    'id' => fallimo_generate_id(),
                    'elType' => 'column',
                    'settings' => ['_column_size' => 100],
                    'elements' => [
                        [
                            'id' => fallimo_generate_id(),
                            'elType' => 'widget',
                            'widgetType' => 'fallimo_services',
                            'settings' => [
                                'section_title' => 'Our Services',
                            ]
                        ]
                    ]
                ]
            ]
        ],
        [
            'id' => fallimo_generate_id(),
            'elType' => 'section',
            'settings' => [],
            'elements' => [
                [
                    'id' => fallimo_generate_id(),
                    'elType' => 'column',
                    'settings' => ['_column_size' => 100],
                    'elements' => [
                        [
                            'id' => fallimo_generate_id(),
                            'elType' => 'widget',
                            'widgetType' => 'fallimo_testimonials',
                            'settings' => [
                                'section_title' => 'What Our Clients Say',
                            ]
                        ]
                    ]
                ]
            ]
        ],
        [
            'id' => fallimo_generate_id(),
            'elType' => 'section',
            'settings' => [],
            'elements' => [
                [
                    'id' => fallimo_generate_id(),
                    'elType' => 'column',
                    'settings' => ['_column_size' => 100],
                    'elements' => [
                        [
                            'id' => fallimo_generate_id(),
                            'elType' => 'widget',
                            'widgetType' => 'fallimo_quote_form',
                            'settings' => [
                                'form_title' => 'Request a Quote',
                                'form_subtitle' => 'Fill out the form below and we\'ll get back to you shortly.',
                            ]
                        ]
                    ]
                ]
            ]
        ],
        [
            'id' => fallimo_generate_id(),
            'elType' => 'section',
            'settings' => [],
            'elements' => [
                [
                    'id' => fallimo_generate_id(),
                    'elType' => 'column',
                    'settings' => ['_column_size' => 100],
                    'elements' => [
                        [
                            'id' => fallimo_generate_id(),
                            'elType' => 'widget',
                            'widgetType' => 'fallimo_footer',
                            'settings' => [
                                'description' => 'Luxury transportation services for all occasions.',
                                'copyright' => '© 2024 Fallimo. All rights reserved.',
                            ]
                        ]
                    ]
                ]
            ]
        ],
    ];
    
    update_post_meta($page_id, '_elementor_data', wp_slash(wp_json_encode($elementor_data)));
    update_post_meta($page_id, '_elementor_page_settings', []);
    
    return $page_id;
}

/**
 * Create Fleet Page
 */
function fallimo_create_fleet_page() {
    $page_id = wp_insert_post([
        'post_title'   => 'Fleet',
        'post_content' => '',
        'post_status'  => 'publish',
        'post_type'    => 'page',
        'post_name'    => 'fleet'
    ]);
    
    if (!$page_id) return false;
    
    update_post_meta($page_id, '_elementor_edit_mode', 'builder');
    update_post_meta($page_id, '_wp_page_template', 'elementor-canvas.php');
    
    return $page_id;
}

/**
 * Create Services Page
 */
function fallimo_create_services_page() {
    $page_id = wp_insert_post([
        'post_title'   => 'Services',
        'post_content' => '',
        'post_status'  => 'publish',
        'post_type'    => 'page',
        'post_name'    => 'services'
    ]);
    
    if (!$page_id) return false;
    
    update_post_meta($page_id, '_elementor_edit_mode', 'builder');
    update_post_meta($page_id, '_wp_page_template', 'elementor-canvas.php');
    
    return $page_id;
}

/**
 * Create Reviews Page
 */
function fallimo_create_reviews_page() {
    $page_id = wp_insert_post([
        'post_title'   => 'Reviews',
        'post_content' => '',
        'post_status'  => 'publish',
        'post_type'    => 'page',
        'post_name'    => 'reviews'
    ]);
    
    if (!$page_id) return false;
    
    update_post_meta($page_id, '_elementor_edit_mode', 'builder');
    update_post_meta($page_id, '_wp_page_template', 'elementor-canvas.php');
    
    return $page_id;
}

/**
 * Create Default Menu
 */
function fallimo_create_default_menu($home_id, $fleet_id, $services_id, $reviews_id) {
    $menu_name = 'Primary Menu';
    $menu_exists = wp_get_nav_menu_object($menu_name);
    
    if (!$menu_exists) {
        $menu_id = wp_create_nav_menu($menu_name);
        
        // Add menu items
        if ($home_id) {
            wp_update_nav_menu_item($menu_id, 0, [
                'menu-item-title' => 'Home',
                'menu-item-object-id' => $home_id,
                'menu-item-object' => 'page',
                'menu-item-type' => 'post_type',
                'menu-item-status' => 'publish'
            ]);
        }
        
        if ($fleet_id) {
            wp_update_nav_menu_item($menu_id, 0, [
                'menu-item-title' => 'Fleet',
                'menu-item-object-id' => $fleet_id,
                'menu-item-object' => 'page',
                'menu-item-type' => 'post_type',
                'menu-item-status' => 'publish'
            ]);
        }
        
        if ($services_id) {
            wp_update_nav_menu_item($menu_id, 0, [
                'menu-item-title' => 'Services',
                'menu-item-object-id' => $services_id,
                'menu-item-object' => 'page',
                'menu-item-type' => 'post_type',
                'menu-item-status' => 'publish'
            ]);
        }
        
        if ($reviews_id) {
            wp_update_nav_menu_item($menu_id, 0, [
                'menu-item-title' => 'Reviews',
                'menu-item-object-id' => $reviews_id,
                'menu-item-object' => 'page',
                'menu-item-type' => 'post_type',
                'menu-item-status' => 'publish'
            ]);
        }
        
        // Assign to theme location
        $locations = get_theme_mod('nav_menu_locations');
        $locations['primary'] = $menu_id;
        set_theme_mod('nav_menu_locations', $locations);
    }
}

/**
 * Configure Elementor Settings
 */
function fallimo_configure_elementor() {
    update_option('elementor_disable_color_schemes', 'yes');
    update_option('elementor_disable_typography_schemes', 'yes');
    update_option('elementor_container_width', '1200');
    update_option('elementor_viewport_lg', '1024');
    update_option('elementor_viewport_md', '768');
    update_option('elementor_load_fa4_shim', 'yes');
}

/**
 * Generate unique Elementor element ID
 */
function fallimo_generate_id() {
    return dechex(mt_rand());
}

/**
 * Add admin notice for successful import
 */
function fallimo_import_success_notice() {
    if (get_option('fallimo_auto_import_done') && !get_option('fallimo_import_notice_dismissed')) {
        ?>
        <div class="notice notice-success is-dismissible">
            <p><strong>Fallimo Theme Activated!</strong> Your homepage has been automatically created with all Elementor widgets. <a href="<?php echo admin_url('post.php?post=' . get_option('page_on_front') . '&action=elementor'); ?>">Edit with Elementor</a> or <a href="<?php echo home_url(); ?>">View Site</a>.</p>
        </div>
        <?php
        update_option('fallimo_import_notice_dismissed', true);
    }
}
add_action('admin_notices', 'fallimo_import_success_notice');
