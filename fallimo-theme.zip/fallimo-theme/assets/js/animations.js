/**
 * Fallimo Theme Animations
 * Intersection Observer for scroll animations
 */

(function() {
    'use strict';

    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    const animateOnScroll = (entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                
                const animationClass = entry.target.getAttribute('data-animation');
                if (animationClass) {
                    entry.target.classList.add(animationClass);
                }
                
                observer.unobserve(entry.target);
            }
        });
    };

    const initAnimations = () => {
        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver(animateOnScroll, observerOptions);
            
            const animatedElements = document.querySelectorAll(
                '.fade-in, .slide-in-left, .slide-in-right, .scale-in, [data-animation]'
            );
            
            animatedElements.forEach(el => {
                el.style.opacity = '0';
                observer.observe(el);
            });
        } else {
            const animatedElements = document.querySelectorAll(
                '.fade-in, .slide-in-left, .slide-in-right, .scale-in, [data-animation]'
            );
            animatedElements.forEach(el => {
                el.classList.add('is-visible');
                el.style.opacity = '1';
            });
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAnimations);
    } else {
        initAnimations();
    }

    document.addEventListener('elementor/frontend/init', () => {
        if (typeof elementorFrontend !== 'undefined') {
            elementorFrontend.hooks.addAction('frontend/element_ready/widget', ($scope) => {
                const animatedElements = $scope.find(
                    '.fade-in, .slide-in-left, .slide-in-right, .scale-in, [data-animation]'
                );
                
                if (animatedElements.length && 'IntersectionObserver' in window) {
                    const observer = new IntersectionObserver(animateOnScroll, observerOptions);
                    animatedElements.each(function() {
                        this.style.opacity = '0';
                        observer.observe(this);
                    });
                }
            });
        }
    });

    const style = document.createElement('style');
    style.textContent = `
        .is-visible {
            opacity: 1 !important;
        }
    `;
    document.head.appendChild(style);
})();
