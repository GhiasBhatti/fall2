<?php
/**
 * Fallimo Theme Functions
 *
 * @package Fallimo
 */

if (!defined('ABSPATH')) {
    exit;
}

define('FALLIMO_VERSION', '1.0.0');
define('FALLIMO_THEME_DIR', get_template_directory());
define('FALLIMO_THEME_URI', get_template_directory_uri());

// Load auto-import functionality
require_once FALLIMO_THEME_DIR . '/includes/auto-import.php';

/**
 * Theme Setup
 */
function fallimo_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 60,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    add_theme_support('customize-selective-refresh-widgets');
    
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'fallimo'),
        'footer'  => __('Footer Menu', 'fallimo'),
    ));
}
add_action('after_setup_theme', 'fallimo_theme_setup');

/**
 * Enqueue Scripts and Styles
 */
function fallimo_enqueue_scripts() {
    wp_enqueue_style('fallimo-style', get_stylesheet_uri(), array(), FALLIMO_VERSION);
    
    wp_enqueue_script('fallimo-animations', FALLIMO_THEME_URI . '/assets/js/animations.js', array(), FALLIMO_VERSION, true);
    
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'fallimo_enqueue_scripts');

/**
 * Add Elementor Support
 */
function fallimo_add_elementor_support() {
    add_theme_support('elementor');
    add_theme_support('elementor-page-builder');
    
    update_option('elementor_disable_color_schemes', 'yes');
    update_option('elementor_disable_typography_schemes', 'yes');
    update_option('elementor_container_width', '1200');
    update_option('elementor_viewport_lg', '1024');
    update_option('elementor_viewport_md', '768');
}
add_action('after_setup_theme', 'fallimo_add_elementor_support');

/**
 * Register Custom Post Type for Fleet Vehicles
 */
function fallimo_register_fleet_cpt() {
    $labels = array(
        'name'               => _x('Fleet Vehicles', 'post type general name', 'fallimo'),
        'singular_name'      => _x('Fleet Vehicle', 'post type singular name', 'fallimo'),
        'menu_name'          => _x('Fleet', 'admin menu', 'fallimo'),
        'add_new'            => _x('Add New Vehicle', 'vehicle', 'fallimo'),
        'add_new_item'       => __('Add New Vehicle', 'fallimo'),
        'edit_item'          => __('Edit Vehicle', 'fallimo'),
        'new_item'           => __('New Vehicle', 'fallimo'),
        'view_item'          => __('View Vehicle', 'fallimo'),
        'search_items'       => __('Search Vehicles', 'fallimo'),
        'not_found'          => __('No vehicles found', 'fallimo'),
        'not_found_in_trash' => __('No vehicles found in Trash', 'fallimo'),
    );

    $args = array(
        'labels'              => $labels,
        'public'              => true,
        'publicly_queryable'  => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'query_var'           => true,
        'rewrite'             => array('slug' => 'fleet'),
        'capability_type'     => 'post',
        'has_archive'         => true,
        'hierarchical'        => false,
        'menu_position'       => 5,
        'menu_icon'           => 'dashicons-car',
        'supports'            => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
        'show_in_rest'        => true,
    );

    register_post_type('fleet_vehicle', $args);
    
    register_taxonomy('vehicle_category', 'fleet_vehicle', array(
        'label'        => __('Vehicle Categories', 'fallimo'),
        'rewrite'      => array('slug' => 'vehicle-category'),
        'hierarchical' => true,
        'show_in_rest' => true,
    ));
}
add_action('init', 'fallimo_register_fleet_cpt');

/**
 * Register Custom Post Type for Quote Requests
 */
function fallimo_register_quote_cpt() {
    $labels = array(
        'name'               => _x('Quote Requests', 'post type general name', 'fallimo'),
        'singular_name'      => _x('Quote Request', 'post type singular name', 'fallimo'),
        'menu_name'          => _x('Quotes', 'admin menu', 'fallimo'),
        'view_item'          => __('View Quote', 'fallimo'),
        'search_items'       => __('Search Quotes', 'fallimo'),
        'not_found'          => __('No quotes found', 'fallimo'),
    );

    $args = array(
        'labels'              => $labels,
        'public'              => false,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'capability_type'     => 'post',
        'capabilities'        => array(
            'create_posts' => 'do_not_allow',
        ),
        'map_meta_cap'        => true,
        'has_archive'         => false,
        'hierarchical'        => false,
        'menu_position'       => 6,
        'menu_icon'           => 'dashicons-email',
        'supports'            => array('title'),
        'show_in_rest'        => true,
    );

    register_post_type('quote_request', $args);
}
add_action('init', 'fallimo_register_quote_cpt');

/**
 * Register REST API Endpoint for Quote Submissions
 */
function fallimo_register_quote_rest_route() {
    register_rest_route('fallimo/v1', '/quotes', array(
        'methods'             => 'POST',
        'callback'            => 'fallimo_submit_quote',
        'permission_callback' => '__return_true',
        'args'                => array(
            'name'            => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
            'email'           => array('required' => true, 'sanitize_callback' => 'sanitize_email'),
            'phone'           => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
            'eventDate'       => array('required' => true, 'sanitize_callback' => 'sanitize_text_field'),
            'eventType'       => array('required' => false, 'sanitize_callback' => 'sanitize_text_field'),
            'vehicleType'     => array('required' => false, 'sanitize_callback' => 'sanitize_text_field'),
            'passengers'      => array('required' => false, 'sanitize_callback' => 'sanitize_text_field'),
            'duration'        => array('required' => false, 'sanitize_callback' => 'sanitize_text_field'),
            'pickupLocation'  => array('required' => false, 'sanitize_callback' => 'sanitize_text_field'),
            'destination'     => array('required' => false, 'sanitize_callback' => 'sanitize_text_field'),
            'message'         => array('required' => false, 'sanitize_callback' => 'sanitize_textarea_field'),
        ),
    ));
}
add_action('rest_api_init', 'fallimo_register_quote_rest_route');

/**
 * Handle Quote Submission
 */
function fallimo_submit_quote($request) {
    $params = $request->get_params();
    
    $post_id = wp_insert_post(array(
        'post_type'   => 'quote_request',
        'post_title'  => sprintf(__('Quote from %s - %s', 'fallimo'), $params['name'], $params['eventDate']),
        'post_status' => 'publish',
    ));
    
    if (is_wp_error($post_id)) {
        return new WP_Error('quote_failed', __('Failed to submit quote request', 'fallimo'), array('status' => 500));
    }
    
    foreach ($params as $key => $value) {
        update_post_meta($post_id, '_fallimo_quote_' . $key, $value);
    }
    
    fallimo_send_quote_notification($post_id, $params);
    
    return new WP_REST_Response(array(
        'success'      => true,
        'quoteRequest' => array(
            'id'        => $post_id,
            'name'      => $params['name'],
            'email'     => $params['email'],
            'eventDate' => $params['eventDate'],
            'createdAt' => current_time('mysql'),
        ),
    ), 201);
}

/**
 * Send Quote Notification Email
 */
function fallimo_send_quote_notification($post_id, $params) {
    $admin_email = get_option('admin_email');
    $notification_email = get_option('fallimo_quote_notification_email', $admin_email);
    
    $subject = sprintf(__('New Quote Request from %s', 'fallimo'), $params['name']);
    
    $message = sprintf(
        __("New Quote Request - Fallimo Luxury Transportation\n\n" .
           "Customer Information:\n" .
           "Name: %s\n" .
           "Email: %s\n" .
           "Phone: %s\n\n" .
           "Event Details:\n" .
           "Event Date: %s\n" .
           "Event Type: %s\n" .
           "Vehicle Type: %s\n" .
           "Number of Passengers: %s\n" .
           "Duration: %s\n\n" .
           "Location Details:\n" .
           "Pickup Location: %s\n" .
           "Destination: %s\n\n" .
           "Additional Message:\n%s\n\n" .
           "Quote Request ID: %d\n" .
           "Submitted: %s", 'fallimo'),
        $params['name'],
        $params['email'],
        $params['phone'],
        $params['eventDate'],
        $params['eventType'] ?? 'N/A',
        $params['vehicleType'] ?? 'N/A',
        $params['passengers'] ?? 'N/A',
        $params['duration'] ?? 'N/A',
        $params['pickupLocation'] ?? 'N/A',
        $params['destination'] ?? 'N/A',
        $params['message'] ?? 'N/A',
        $post_id,
        current_time('mysql')
    );
    
    wp_mail($notification_email, $subject, $message);
}

/**
 * Register Fallimo Elementor Widget Category
 */
function fallimo_add_elementor_widget_categories($elements_manager) {
    $elements_manager->add_category(
        'fallimo',
        [
            'title' => __('Fallimo Widgets', 'fallimo'),
            'icon' => 'fa fa-plug',
        ]
    );
}
add_action('elementor/elements/categories_registered', 'fallimo_add_elementor_widget_categories');

/**
 * Add Settings Page for Email Configuration
 */
function fallimo_add_settings_page() {
    add_options_page(
        __('Fallimo Settings', 'fallimo'),
        __('Fallimo Settings', 'fallimo'),
        'manage_options',
        'fallimo-settings',
        'fallimo_settings_page_html'
    );
}
add_action('admin_menu', 'fallimo_add_settings_page');

function fallimo_settings_page_html() {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    if (isset($_POST['fallimo_save_settings'])) {
        check_admin_referer('fallimo_settings');
        update_option('fallimo_quote_notification_email', sanitize_email($_POST['notification_email']));
        echo '<div class="updated"><p>' . __('Settings saved.', 'fallimo') . '</p></div>';
    }
    
    $notification_email = get_option('fallimo_quote_notification_email', get_option('admin_email'));
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        <form method="post" action="">
            <?php wp_nonce_field('fallimo_settings'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="notification_email"><?php _e('Quote Notification Email', 'fallimo'); ?></label></th>
                    <td><input type="email" id="notification_email" name="notification_email" value="<?php echo esc_attr($notification_email); ?>" class="regular-text"></td>
                </tr>
            </table>
            <?php submit_button(__('Save Settings', 'fallimo'), 'primary', 'fallimo_save_settings'); ?>
        </form>
    </div>
    <?php
}
