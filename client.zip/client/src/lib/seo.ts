// SEO Configuration and Utilities - WordPress-like SEO Management
export interface SEOConfig {
  title: string;
  description: string;
  keywords: string;
  canonical?: string;
  ogImage?: string;
  ogType?: 'website' | 'article' | 'service';
  schema?: Record<string, any>;
  breadcrumbs?: BreadcrumbItem[];
}

export interface BreadcrumbItem {
  name: string;
  url: string;
}

// Base SEO configuration
export const baseSEO = {
  siteName: "Fallimo Luxury Transportation",
  siteUrl: typeof window !== 'undefined' ? window.location.origin : "",
  defaultImage: "/favicon.png",
  businessInfo: {
    name: "Fallimo Luxury Transportation",
    phone: "800-701-0024",
    email: "info@fallimo.com",
    address: {
      street: "123 Transportation Way",
      city: "New York",
      state: "NY",
      zip: "10001",
      country: "US"
    },
    serviceAreas: ["New York", "New Jersey", "Connecticut", "Pennsylvania"],
    rating: 4.8,
    reviewCount: 500
  }
};

// Page-specific SEO configurations
export const seoConfigs: Record<string, SEOConfig> = {
  home: {
    title: "Fallimo - Luxury Party Bus & Limousine Service | NY, NJ, CT, PA",
    description: "Premium party bus and limousine rental service. Luxury transportation for weddings, corporate events, and special occasions. Serving NY, NJ, CT, PA with 4.8-star rated service.",
    keywords: "party bus rental, limousine service, luxury transportation, wedding limo, corporate transport, NYC party bus, NJ limo service, CT luxury transport, PA party bus",
    ogType: "website",
    breadcrumbs: [
      { name: "Home", url: "/" }
    ]
  },
  fleet: {
    title: "Our Luxury Fleet - Party Buses & Limousines | Fallimo",
    description: "Explore our premium fleet of party buses and limousines. Modern vehicles with luxury amenities for 2-55 passengers. Professional service across NY, NJ, CT, PA.",
    keywords: "luxury party bus fleet, limousine models, party bus sizes, wedding limo fleet, corporate transportation vehicles, luxury transport options",
    ogType: "website",
    breadcrumbs: [
      { name: "Home", url: "/" },
      { name: "Fleet", url: "/fleet" }
    ]
  },
  services: {
    title: "Luxury Transportation Services - Weddings, Corporate & Events | Fallimo",
    description: "Professional party bus and limousine services for weddings, corporate events, airport transfers, and special occasions. 24/7 availability with expert chauffeurs.",
    keywords: "wedding transportation, corporate limo service, airport transfers, special event transport, party bus services, professional chauffeurs, 24/7 luxury transport",
    ogType: "service",
    breadcrumbs: [
      { name: "Home", url: "/" },
      { name: "Services", url: "/services" }
    ]
  },
  reviews: {
    title: "Customer Reviews & Testimonials | Fallimo Luxury Transportation",
    description: "Read authentic reviews from satisfied customers. 4.8-star rated luxury transportation service with hundreds of positive testimonials from NY, NJ, CT, PA.",
    keywords: "customer reviews, transportation testimonials, party bus reviews, limousine service feedback, luxury transport ratings, customer satisfaction",
    ogType: "website",
    breadcrumbs: [
      { name: "Home", url: "/" },
      { name: "Reviews", url: "/reviews" }
    ]
  }
};

// Generate structured data for different page types
export const generateOrganizationSchema = () => ({
  "@context": "https://schema.org",
  "@type": "AutomotiveBusiness",
  "name": baseSEO.businessInfo.name,
  "description": "Premium party bus and limousine rental service offering luxury transportation for weddings, corporate events, and special occasions",
  "telephone": baseSEO.businessInfo.phone,
  "email": baseSEO.businessInfo.email,
  "url": baseSEO.siteUrl,
  "logo": `${baseSEO.siteUrl}/favicon.png`,
  "image": `${baseSEO.siteUrl}/favicon.png`,
  "priceRange": "$$",
  "currenciesAccepted": "USD",
  "paymentAccepted": "Cash, Credit Card, Debit Card",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": baseSEO.businessInfo.address.street,
    "addressLocality": baseSEO.businessInfo.address.city,
    "addressRegion": baseSEO.businessInfo.address.state,
    "postalCode": baseSEO.businessInfo.address.zip,
    "addressCountry": baseSEO.businessInfo.address.country
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 40.7128,
    "longitude": -74.0060
  },
  "areaServed": baseSEO.businessInfo.serviceAreas.map(area => ({
    "@type": "State",
    "name": area
  })),
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": baseSEO.businessInfo.rating,
    "ratingCount": baseSEO.businessInfo.reviewCount,
    "bestRating": 5,
    "worstRating": 1
  },
  "openingHoursSpecification": [{
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    "opens": "00:00",
    "closes": "23:59"
  }],
  "sameAs": [
    // Add social media links when available
  ]
});

export const generateServiceSchema = () => ({
  "@context": "https://schema.org",
  "@type": "Service",
  "name": "Party Bus and Limousine Rental",
  "description": "Luxury party bus and limousine rental service for weddings, corporate events, and special occasions",
  "provider": {
    "@type": "AutomotiveBusiness",
    "name": baseSEO.businessInfo.name,
    "telephone": baseSEO.businessInfo.phone,
    "url": baseSEO.siteUrl
  },
  "serviceType": "Transportation Service",
  "areaServed": baseSEO.businessInfo.serviceAreas.map(area => ({
    "@type": "State",
    "name": area
  })),
  "offers": [
    {
      "@type": "Offer",
      "name": "Party Bus Rental",
      "description": "Luxury party bus rental for events and celebrations"
    },
    {
      "@type": "Offer", 
      "name": "Limousine Service",
      "description": "Premium limousine service for weddings and special occasions"
    },
    {
      "@type": "Offer",
      "name": "Corporate Transportation",
      "description": "Professional transportation for business events and meetings"
    }
  ]
});

export const generateWebsiteSchema = () => ({
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": baseSEO.siteName,
  "description": "Premium party bus and limousine rental service across NY, NJ, CT, PA",
  "url": baseSEO.siteUrl,
  "potentialAction": {
    "@type": "SearchAction",
    "target": {
      "@type": "EntryPoint",
      "urlTemplate": `${baseSEO.siteUrl}/?q={search_term_string}`
    },
    "query-input": "required name=search_term_string"
  }
});

export const generateBreadcrumbSchema = (breadcrumbs: BreadcrumbItem[]) => ({
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": breadcrumbs.map((item, index) => ({
    "@type": "ListItem",
    "position": index + 1,
    "name": item.name,
    "item": `${baseSEO.siteUrl}${item.url}`
  }))
});

export const generateFAQSchema = (faqs: Array<{question: string, answer: string}>) => ({
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": faqs.map(faq => ({
    "@type": "Question",
    "name": faq.question,
    "acceptedAnswer": {
      "@type": "Answer",
      "text": faq.answer
    }
  }))
});

// Dynamic meta tag updates (like WordPress)
export const updateMetaTags = (config: SEOConfig) => {
  if (typeof document === 'undefined') return;

  // Update title
  document.title = config.title;

  // Update or create meta tags
  const updateMeta = (name: string, content: string, property = false) => {
    const attribute = property ? 'property' : 'name';
    let meta = document.querySelector(`meta[${attribute}="${name}"]`) as HTMLMetaElement;
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute(attribute, name);
      document.head.appendChild(meta);
    }
    meta.content = content;
  };

  // Basic meta tags
  updateMeta('description', config.description);
  updateMeta('keywords', config.keywords);
  
  // Open Graph tags
  updateMeta('og:title', config.title, true);
  updateMeta('og:description', config.description, true);
  updateMeta('og:type', config.ogType || 'website', true);
  updateMeta('og:url', `${baseSEO.siteUrl}${config.canonical || window.location.pathname}`, true);
  updateMeta('og:image', config.ogImage || `${baseSEO.siteUrl}/favicon.png`, true);
  
  // Twitter tags
  updateMeta('twitter:title', config.title, true);
  updateMeta('twitter:description', config.description, true);
  updateMeta('twitter:image', config.ogImage || `${baseSEO.siteUrl}/favicon.png`, true);

  // Update canonical link
  let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
  if (!canonical) {
    canonical = document.createElement('link');
    canonical.rel = 'canonical';
    document.head.appendChild(canonical);
  }
  canonical.href = `${baseSEO.siteUrl}${config.canonical || window.location.pathname}`;
};

// Add structured data to page
export const addStructuredData = (id: string, schema: Record<string, any>) => {
  if (typeof document === 'undefined') return;

  // Remove existing schema with same id
  const existing = document.getElementById(id);
  if (existing) {
    existing.remove();
  }

  // Add new schema
  const script = document.createElement('script');
  script.type = 'application/ld+json';
  script.id = id;
  script.textContent = JSON.stringify(schema);
  document.head.appendChild(script);
};