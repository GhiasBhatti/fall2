import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useSEO, usePagePerformance } from "@/hooks/useSEO";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { FAQ } from "@/components/FAQ";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";
import { useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Heart, 
  Briefcase, 
  PartyPopper, 
  GraduationCap, 
  Users, 
  MapPin,
  Clock,
  Shield,
  Star,
  Phone,
  Calendar
} from "lucide-react";

const services = [
  {
    id: 1,
    icon: Heart,
    title: "Wedding Transportation",
    description: "Make your special day even more memorable with our elegant wedding transportation services.",
    features: ["Bridal party transportation", "Decorated vehicles", "Red carpet service", "Professional chauffeurs", "Flexible timing", "Multiple pickup locations"],
    popular: true,
    category: "Special Events"
  },
  {
    id: 2,
    icon: Briefcase,
    title: "Corporate Events",
    description: "Professional transportation solutions for business meetings, conferences, and corporate gatherings.",
    features: ["Executive vehicles", "WiFi availability", "Professional drivers", "On-time guarantee", "Group coordination", "Expense reporting"],
    popular: false,
    category: "Business"
  },
  {
    id: 3,
    icon: PartyPopper,
    title: "Party & Celebrations",
    description: "Turn any celebration into an unforgettable experience with our party transportation services.",
    features: ["Party buses with entertainment", "Bachelor/bachelorette parties", "Birthday celebrations", "Night out transportation", "Safe designated driving", "Multiple stops"],
    popular: true,
    category: "Entertainment"
  },
  {
    id: 4,
    icon: GraduationCap,
    title: "Prom & School Events",
    description: "Safe and stylish transportation for prom nights, homecoming, and other school celebrations.",
    features: ["Teen-safe environment", "Parent communication", "Group packages", "Photo opportunities", "Supervised service", "Affordable rates"],
    popular: false,
    category: "Student Events"
  },
  {
    id: 5,
    icon: MapPin,
    title: "Airport Transportation",
    description: "Reliable and comfortable airport transfers with flight monitoring and meet & greet service.",
    features: ["Flight tracking", "Meet & greet service", "Luggage assistance", "All major airports", "On-time guarantee", "24/7 availability"],
    popular: false,
    category: "Travel"
  },
  {
    id: 6,
    icon: Users,
    title: "Group Transportation",
    description: "Coordinate transportation for large groups with our fleet of buses and multi-vehicle solutions.",
    features: ["Large group coordination", "Multiple vehicles", "Event planning assistance", "Custom routes", "Group discounts", "Professional coordination"],
    popular: false,
    category: "Group Events"
  }
];

const whyChooseUs = [
  {
    icon: Shield,
    title: "Licensed & Insured",
    description: "Fully licensed transportation company with comprehensive insurance coverage for your peace of mind."
  },
  {
    icon: Star,
    title: "4.8 Star Rating",
    description: "Consistently rated as the top luxury transportation service with over 500 five-star reviews."
  },
  {
    icon: Clock,
    title: "On-Time Guarantee",
    description: "We guarantee punctual service with real-time tracking and proactive communication."
  },
  {
    icon: Users,
    title: "Professional Chauffeurs",
    description: "Background-checked, professionally trained drivers committed to your safety and comfort."
  }
];

// SEO-optimized FAQ data for services
const servicesFAQs = [
  {
    question: "What types of events do you provide transportation for?",
    answer: "We provide luxury transportation for weddings, corporate events, airport transfers, parties, proms, graduations, and any special occasion requiring premium transport services."
  },
  {
    question: "How do I choose the right vehicle for my event?",
    answer: "Our team will help you select the perfect vehicle based on your group size, event type, and specific needs. We offer party buses for larger groups and limousines for intimate occasions."
  },
  {
    question: "Are your chauffeurs professionally trained?",
    answer: "Yes, all our chauffeurs are professionally trained, licensed, insured, and background-checked. They provide courteous service and prioritize your safety and comfort."
  },
  {
    question: "What safety measures do you have in place?",
    answer: "All vehicles undergo regular safety inspections, our chauffeurs are trained in defensive driving, and we maintain comprehensive insurance coverage for your protection."
  },
  {
    question: "Can you accommodate special requests?",
    answer: "Absolutely! We can accommodate special decorations, multiple stops, custom routes, and other special requests to make your event perfect."
  }
];

const goToQuoteSection = (location: string, navigate: any) => {
  if (location === '/') {
    // Already on homepage, just scroll to quote section
    const element = document.getElementById('quote');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  } else {
    // Fast SPA navigation to homepage, then instant scroll to quote
    navigate('/');
    requestAnimationFrame(() => {
      const element = document.getElementById('quote');
      if (element) {
        element.scrollIntoView({ behavior: 'auto' }); // Instant scroll for speed
      }
    });
  }
};

export default function Services() {
  useIntersectionObserver();
  const seoData = useSEO('services');
  usePagePerformance();
  const [location, navigate] = useLocation();
  
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Breadcrumbs items={seoData.breadcrumbs || []} className="container mx-auto px-4 pt-4" />
      
      <main>
        {/* Hero Section */}
        <section className="relative py-20 bg-gradient-to-r from-primary/10 via-primary/5 to-background">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center max-w-4xl mx-auto">
              <h1 className="text-4xl md:text-6xl font-bold mb-6 text-foreground">
                Our Services
              </h1>
              <p className="text-xl text-muted-foreground mb-8">
                From weddings to corporate events, we provide luxury transportation services 
                tailored to make your special occasions unforgettable.
              </p>
              <div className="flex items-center justify-center gap-6 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-primary" />
                  <span>Licensed & Insured</span>
                </div>
                <div className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-primary" />
                  <span>4.8 Star Rating</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-primary" />
                  <span>24/7 Availability</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Services Grid */}
        <section className="py-16">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service, index) => (
                <Card 
                  key={service.id} 
                  className={`group ${service.popular ? 'card-manifest-hover card-pulse-glow card-energy-flow' : 'card-premium-hover card-glow-hover'} relative overflow-hidden ${index % 3 === 0 ? 'animate-manifest-spiral' : index % 3 === 1 ? 'animate-manifest-bounce' : 'animate-manifest-pop'} animate-on-scroll animate-delay-${index * 150}`}
                  data-testid={`card-service-${service.id}`}
                >
                  {service.popular && (
                    <div className="absolute top-4 right-4 z-10">
                      <Badge className="bg-primary text-primary-foreground">
                        <Star className="w-3 h-3 mr-1" />
                        Popular
                      </Badge>
                    </div>
                  )}
                  
                  <CardHeader className="pb-4">
                    <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors duration-300">
                      <service.icon className="w-8 h-8 text-primary" />
                    </div>
                    <div className="space-y-2">
                      <Badge variant="outline" className="text-xs">
                        {service.category}
                      </Badge>
                      <CardTitle className="text-xl" data-testid={`text-service-title-${service.id}`}>
                        {service.title}
                      </CardTitle>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <p className="text-muted-foreground mb-4" data-testid={`text-service-description-${service.id}`}>
                      {service.description}
                    </p>
                    
                    <div className="space-y-3">
                      <h4 className="font-semibold text-sm text-foreground">What's Included:</h4>
                      <ul className="space-y-1">
                        {service.features.map((feature, index) => (
                          <li key={index} className="text-sm text-muted-foreground flex items-center gap-2">
                            <div className="w-1 h-1 bg-primary rounded-full flex-shrink-0"></div>
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div className="mt-6 pt-4 border-t border-border">
                      <Button 
                        className="w-full h-11 group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300"
                        variant="outline"
                        onClick={() => goToQuoteSection(location, navigate)}
                        data-testid={`button-quote-${service.id}`}
                      >
                        Get Quote
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="py-16 bg-card">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-foreground">
                Why Choose Fallimo?
              </h2>
              <p className="text-lg text-muted-foreground">
                We're committed to providing exceptional service that exceeds your expectations 
                every time you choose us for your transportation needs.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {whyChooseUs.map((item, index) => (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <item.icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3 text-foreground">{item.title}</h3>
                  <p className="text-muted-foreground">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-gradient-to-r from-primary via-primary to-primary/90">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center max-w-3xl mx-auto text-white">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Ready to Book Your Service?
              </h2>
              <p className="text-xl mb-8 text-primary-foreground/90">
                Contact us today for a personalized quote and experience the luxury of professional transportation.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button 
                  size="lg" 
                  variant="secondary"
                  className="min-w-[200px]"
                  onClick={() => goToQuoteSection(location, navigate)}
                  data-testid="button-get-quote"
                >
                  Get Free Quote
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  className="min-w-[200px] bg-white/10 border-white/20 text-white hover:bg-white hover:text-primary"
                  data-testid="button-call-now"
                >
                  <Phone className="w-4 h-4 mr-2" />
                  Call Now: 800-701-0024
                </Button>
              </div>
            </div>
          </div>
        </section>
        
        <FAQ 
          faqs={servicesFAQs}
          title="Service FAQs"
          className="py-16 bg-gradient-to-b from-purple-900/20 to-black"
        />
      </main>

      <Footer />
    </div>
  );
}