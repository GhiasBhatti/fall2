import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useSEO, usePagePerformance } from "@/hooks/useSEO";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { FAQ } from "@/components/FAQ";
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";
import { Users, Shield, Calendar, Star, MapPin, Zap } from "lucide-react";
import partyBusImage from "@assets/stock_images/luxury_party_bus_int_68646f3a.jpg";
import limousineImage from "@assets/stock_images/luxury_limousine_ext_55d719e9.jpg";
import sprinterVanImage from "@assets/generated_images/Party_bus_interior_b9820753.png";

const fleetData = {
  "Party Buses": [
    { id: 1, name: "Elite Party Bus", capacity: "30-35", image: partyBusImage, amenities: ["LED Lighting", "Premium Sound", "Mini Bar", "Leather Seating"] },
    { id: 2, name: "VIP Party Bus", capacity: "25-30", image: partyBusImage, amenities: ["Color LED Lights", "Sound System", "Bar Area", "Dance Floor"] },
    { id: 3, name: "Luxury Party Bus", capacity: "20-25", image: partyBusImage, amenities: ["Premium Audio", "Lighting", "Refreshments", "Comfort Seating"] }
  ],
  "Limousines": [
    { id: 4, name: "Stretch Limo", capacity: "8-10", image: limousineImage, amenities: ["Premium Bar", "Entertainment", "Privacy", "Luxury Interior"] },
    { id: 5, name: "SUV Limousine", capacity: "14-16", image: limousineImage, amenities: ["Spacious Interior", "Bar Setup", "Sound System", "LED Lighting"] },
    { id: 6, name: "Classic Limo", capacity: "6-8", image: limousineImage, amenities: ["Traditional Luxury", "Premium Service", "Comfort", "Style"] }
  ],
  "Sprinter Vans": [
    { id: 7, name: "Executive Sprinter", capacity: "12-14", image: sprinterVanImage, amenities: ["Business Setup", "WiFi", "Comfort Seats", "Climate Control"] },
    { id: 8, name: "Luxury Sprinter", capacity: "10-12", image: sprinterVanImage, amenities: ["Premium Interior", "Entertainment", "Bar Area", "LED Lighting"] }
  ]
};

// SEO-optimized FAQ data for fleet
const fleetFAQs = [
  {
    question: "What types of vehicles are in your fleet?",
    answer: "Our fleet includes luxury party buses (20-35 passengers), stretch limousines (6-16 passengers), and executive sprinter vans (10-14 passengers), all equipped with premium amenities."
  },
  {
    question: "Are your vehicles regularly maintained?",
    answer: "Yes, all our vehicles undergo rigorous maintenance schedules and safety inspections to ensure optimal performance, safety, and luxury standards for every ride."
  },
  {
    question: "What amenities are included in your vehicles?",
    answer: "Our vehicles feature LED lighting, premium sound systems, leather seating, climate control, and bar areas. Specific amenities vary by vehicle type and can be customized for your event."
  },
  {
    question: "How do I choose the right vehicle for my group?",
    answer: "Consider your group size, event type, and desired amenities. Our team can recommend the perfect vehicle based on your specific needs and preferences."
  },
  {
    question: "Can I see the vehicles before booking?",
    answer: "Absolutely! We encourage customers to view our vehicles. Contact us to schedule a viewing appointment at our facility."
  }
];

export default function Fleet() {
  const [selectedCategory, setSelectedCategory] = useState("Party Buses");
  useIntersectionObserver();
  const seoData = useSEO('fleet');
  usePagePerformance();

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Breadcrumbs items={seoData.breadcrumbs || []} className="container mx-auto px-4 pt-4" />
      
      <main>
        {/* Hero Section */}
        <section className="relative py-20 bg-gradient-to-r from-primary/10 via-primary/5 to-background">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center max-w-4xl mx-auto">
              <h1 className="text-4xl md:text-6xl font-bold mb-6 text-foreground">
                Our Luxury Fleet
              </h1>
              <p className="text-xl text-muted-foreground mb-8">
                Discover our premium collection of party buses, limousines, and luxury vehicles. 
                Each vehicle is meticulously maintained and equipped with top-tier amenities for your comfort and enjoyment.
              </p>
              <div className="flex items-center justify-center gap-6 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-primary" />
                  <span>Fully Insured</span>
                </div>
                <div className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-primary" />
                  <span>Professional Service</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-primary" />
                  <span>24/7 Availability</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Fleet Categories */}
        <section className="py-16">
          <div className="container mx-auto px-4 lg:px-8">
            {/* Category Tabs */}
            <div className="flex flex-wrap justify-center gap-4 mb-12">
              {Object.keys(fleetData).map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                    selectedCategory === category
                      ? 'bg-primary text-primary-foreground shadow-lg'
                      : 'bg-card text-card-foreground hover:bg-primary/10 border border-border'
                  }`}
                  data-testid={`button-category-${category.toLowerCase().replace(' ', '-')}`}
                >
                  {category}
                </button>
              ))}
            </div>

            {/* Vehicle Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {fleetData[selectedCategory as keyof typeof fleetData].map((vehicle, index) => (
                <Card 
                  key={vehicle.id} 
                  className={`group card-hover-lift card-glow-hover overflow-hidden animate-fade-in-scale animate-on-scroll animate-delay-${index * 150}`}
                  data-testid={`card-vehicle-${vehicle.id}`}
                >
                  {/* Vehicle Image */}
                  <div className="h-48 relative overflow-hidden">
                    <img 
                      src={vehicle.image}
                      alt={`${vehicle.name} interior`}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      loading="lazy"
                      decoding="async"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    
                    {/* Capacity Badge */}
                    <div className="absolute top-4 left-4">
                      <Badge variant="secondary" className="bg-white/90 text-gray-900">
                        <Users className="w-3 h-3 mr-1" />
                        {vehicle.capacity} Passengers
                      </Badge>
                    </div>
                    
                    {/* Featured Badge */}
                    <div className="absolute top-4 right-4">
                      <Badge className="bg-primary text-primary-foreground">
                        <Star className="w-3 h-3 mr-1" />
                        Popular
                      </Badge>
                    </div>
                  </div>
                  
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold mb-3 text-foreground" data-testid={`text-vehicle-name-${vehicle.id}`}>
                      {vehicle.name}
                    </h3>
                    
                    {/* Amenities */}
                    <div className="space-y-2">
                      <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">
                        Amenities
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {vehicle.amenities.map((amenity, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {amenity}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    {/* Features */}
                    <div className="mt-4 grid grid-cols-2 gap-3 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Zap className="w-4 h-4 text-primary" />
                        <span>Premium Audio</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-primary" />
                        <span>GPS Tracking</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Fleet Features */}
        <section className="py-16 bg-card">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-foreground">
                Why Choose Our Fleet?
              </h2>
              <p className="text-lg text-muted-foreground">
                Every vehicle in our fleet is carefully selected and maintained to the highest standards, 
                ensuring your safety, comfort, and enjoyment throughout your journey.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-foreground">Safety First</h3>
                <p className="text-muted-foreground">All vehicles undergo regular safety inspections and maintenance</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-foreground">Luxury Amenities</h3>
                <p className="text-muted-foreground">Premium sound systems, LED lighting, and comfort features</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-foreground">Group Friendly</h3>
                <p className="text-muted-foreground">Vehicles accommodating groups from 6 to 35 passengers</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calendar className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-foreground">Available 24/7</h3>
                <p className="text-muted-foreground">Round-the-clock service for your convenience</p>
              </div>
            </div>
          </div>
        </section>
        <FAQ 
          faqs={fleetFAQs}
          title="Fleet FAQs"
          className="py-16 bg-gradient-to-b from-purple-900/20 to-black"
        />
      </main>

      <Footer />
    </div>
  );
}