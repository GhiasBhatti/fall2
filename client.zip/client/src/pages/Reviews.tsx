import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useSEO, usePagePerformance } from "@/hooks/useSEO";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { FAQ } from "@/components/FAQ";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star, Quote, MapPin, Calendar, Users, Award } from "lucide-react";
import { useLocation } from "wouter";
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";

// SEO-optimized FAQ data for reviews
const reviewsFAQs = [
  {
    question: "How do you collect customer reviews?",
    answer: "We collect reviews from actual customers after their transportation service is completed. All reviews are verified and authentic to maintain transparency and trust."
  },
  {
    question: "What makes Fallimo's service special?",
    answer: "Our commitment to luxury, safety, and customer satisfaction sets us apart. With professional chauffeurs, premium vehicles, and 24/7 availability, we consistently exceed expectations."
  },
  {
    question: "How do you maintain such high customer satisfaction?",
    answer: "We focus on attention to detail, punctual service, well-maintained vehicles, and continuous staff training. Customer feedback helps us constantly improve our service quality."
  },
  {
    question: "Can I leave a review after my service?",
    answer: "Absolutely! We encourage all customers to share their experience. You'll receive a follow-up email after your service with a link to leave a review."
  },
  {
    question: "Do you respond to customer feedback?",
    answer: "Yes, we actively monitor and respond to all customer feedback. We use reviews to identify areas for improvement and ensure consistent service excellence."
  }
];

const goToQuoteSection = (location: string, navigate: any) => {
  if (location === '/') {
    // Already on homepage, just scroll to quote section
    const element = document.getElementById('quote');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  } else {
    // Fast SPA navigation to homepage, then instant scroll to quote
    navigate('/');
    requestAnimationFrame(() => {
      const element = document.getElementById('quote');
      if (element) {
        element.scrollIntoView({ behavior: 'auto' }); // Instant scroll for speed
      }
    });
  }
};

const testimonials = [
  {
    id: 1,
    name: "Sarah Mitchell",
    location: "New York, NY",
    rating: 5,
    date: "December 2024",
    event: "Wedding",
    text: "Fallimo made our wedding day absolutely perfect! The limousine was pristine, the driver was professional and courteous, and everything went exactly as planned. Highly recommend!",
    avatar: null,
    verified: true
  },
  {
    id: 2,
    name: "Michael Johnson",
    location: "Newark, NJ",
    rating: 5,
    date: "November 2024",
    event: "Corporate Event",
    text: "Used Fallimo for our company retreat transportation. Excellent service, on-time pickup, and the party bus was equipped with everything we needed. Will definitely use again!",
    avatar: null,
    verified: true
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    location: "Philadelphia, PA",
    rating: 5,
    date: "October 2024",
    event: "Birthday Party",
    text: "Amazing experience for my 30th birthday! The party bus was incredible with great sound system and lighting. The driver was fantastic and made our night memorable.",
    avatar: null,
    verified: true
  },
  {
    id: 4,
    name: "David Thompson",
    location: "Stamford, CT",
    rating: 5,
    date: "September 2024",
    event: "Prom Night",
    text: "Perfect prom transportation for our group of 12. Parents felt comfortable with the safety measures, and we had an unforgettable night. Thank you Fallimo!",
    avatar: null,
    verified: true
  },
  {
    id: 5,
    name: "Jennifer Walsh",
    location: "Jersey City, NJ",
    rating: 5,
    date: "August 2024",
    event: "Bachelorette Party",
    text: "The party bus was absolutely perfect for our bachelorette weekend! Clean, fun atmosphere, and the driver accommodated all our stops. Couldn't have asked for better service.",
    avatar: null,
    verified: true
  },
  {
    id: 6,
    name: "Robert Chen",
    location: "Manhattan, NY",
    rating: 5,
    date: "July 2024",
    event: "Airport Transfer",
    text: "Professional airport transfer service. Driver was waiting for us with a sign, helped with luggage, and got us to the airport with time to spare. Stress-free experience!",
    avatar: null,
    verified: true
  },
  {
    id: 7,
    name: "Amanda Foster",
    location: "Trenton, NJ",
    rating: 5,
    date: "June 2024",
    event: "Anniversary",
    text: "Celebrated our 25th anniversary with a romantic limousine ride. The service was impeccable, the vehicle was luxurious, and it made our special day even more memorable.",
    avatar: null,
    verified: true
  },
  {
    id: 8,
    name: "Mark Williams",
    location: "Bridgeport, CT",
    rating: 5,
    date: "May 2024",
    event: "Graduation",
    text: "Hired Fallimo for my daughter's graduation celebration. Excellent communication, professional service, and fair pricing. The whole family was impressed!",
    avatar: null,
    verified: true
  },
  {
    id: 9,
    name: "Lisa Garcia",
    location: "Newark, NJ",
    rating: 5,
    date: "April 2024",
    event: "Wine Tour",
    text: "Perfect for our wine tasting tour! The driver was knowledgeable about the area, kept us safe, and the party bus made the experience so much more enjoyable.",
    avatar: null,
    verified: true
  }
];

const stats = [
  { number: "500+", label: "Happy Customers", icon: Users },
  { number: "4.8", label: "Average Rating", icon: Star },
  { number: "50+", label: "Events Per Month", icon: Calendar },
  { number: "5", label: "Years of Service", icon: Award }
];

export default function Reviews() {
  useIntersectionObserver();
  const seoData = useSEO('reviews');
  usePagePerformance();
  const [location, navigate] = useLocation();
  const averageRating = 4.8;
  const totalReviews = testimonials.length;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Breadcrumbs items={seoData.breadcrumbs || []} className="container mx-auto px-4 pt-4" />
      
      <main>
        {/* Hero Section */}
        <section className="relative py-20 bg-gradient-to-r from-primary/10 via-primary/5 to-background">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center max-w-4xl mx-auto">
              <h1 className="text-4xl md:text-6xl font-bold mb-6 text-foreground">
                Customer Reviews
              </h1>
              <p className="text-xl text-muted-foreground mb-8">
                Don't just take our word for it. See what our customers say about their 
                luxury transportation experience with Fallimo.
              </p>
              
              {/* Rating Overview */}
              <div className="flex items-center justify-center gap-8 mb-8">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <span className="text-4xl font-bold text-primary">{averageRating}</span>
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`w-6 h-6 ${
                            i < Math.floor(averageRating) 
                              ? 'text-yellow-400 fill-current' 
                              : 'text-gray-300'
                          }`} 
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Based on {totalReviews}+ verified reviews
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 bg-card">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <div key={index} className={`text-center animate-fade-in-scale animate-on-scroll animate-delay-${index * 150}`}>
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <stat.icon className="w-8 h-8 text-primary" />
                  </div>
                  <div className="text-3xl font-bold text-primary mb-2">{stat.number}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Reviews Grid */}
        <section className="py-16">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
                What Our Customers Say
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Real reviews from real customers who have experienced our luxury transportation services.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <Card 
                  key={testimonial.id} 
                  className={`group card-premium-hover card-glow-hover card-energy-flow relative overflow-hidden ${index % 3 === 0 ? 'animate-manifest-spiral' : index % 3 === 1 ? 'animate-manifest-bounce' : 'animate-manifest-pop'} animate-on-scroll animate-delay-${index * 120}`}
                  data-testid={`card-review-${testimonial.id}`}
                >
                  <CardContent className="p-6">
                    {/* Quote Icon */}
                    <div className="mb-4">
                      <Quote className="w-8 h-8 text-primary/30" />
                    </div>

                    {/* Rating */}
                    <div className="flex items-center gap-1 mb-4">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`w-4 h-4 ${
                            i < testimonial.rating 
                              ? 'text-yellow-400 fill-current' 
                              : 'text-gray-300'
                          }`} 
                        />
                      ))}
                      <span className="ml-2 text-sm text-muted-foreground">
                        {testimonial.rating}.0
                      </span>
                    </div>

                    {/* Review Text */}
                    <p className="text-foreground mb-6 leading-relaxed" data-testid={`text-review-${testimonial.id}`}>
                      {testimonial.text}
                    </p>

                    {/* Customer Info */}
                    <div className="flex items-center gap-3 mb-4">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={testimonial.avatar || undefined} alt={testimonial.name} />
                        <AvatarFallback>
                          {testimonial.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold text-foreground" data-testid={`text-customer-name-${testimonial.id}`}>
                            {testimonial.name}
                          </h4>
                          {testimonial.verified && (
                            <Badge variant="secondary" className="text-xs">
                              Verified
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <MapPin className="w-3 h-3" />
                          <span>{testimonial.location}</span>
                        </div>
                      </div>
                    </div>

                    {/* Event & Date */}
                    <div className="flex items-center justify-between text-sm text-muted-foreground border-t border-border pt-4">
                      <Badge variant="outline" className="text-xs">
                        {testimonial.event}
                      </Badge>
                      <span>{testimonial.date}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-gradient-to-r from-primary via-primary to-primary/90">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center max-w-3xl mx-auto text-white">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Join Our Happy Customers
              </h2>
              <p className="text-xl mb-8 text-primary-foreground/90">
                Experience the luxury and professionalism that has earned us hundreds of five-star reviews.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button 
                  size="lg" 
                  variant="secondary"
                  className="min-w-[200px]"
                  onClick={() => goToQuoteSection(location, navigate)}
                  data-testid="button-book-now"
                >
                  Book Your Ride
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  className="min-w-[200px] bg-white/10 border-white/20 text-white hover:bg-white hover:text-primary"
                  onClick={() => goToQuoteSection(location, navigate)}
                  data-testid="button-get-quote"
                >
                  Get Free Quote
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Leave Review Section */}
        <section className="py-16 bg-card">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="text-center max-w-2xl mx-auto">
              <h2 className="text-3xl font-bold mb-6 text-foreground">
                Share Your Experience
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Recently used our service? We'd love to hear about your experience and share it with future customers.
              </p>
              <Button size="lg" data-testid="button-leave-review">
                Leave a Review
              </Button>
            </div>
          </div>
        </section>
        
        <FAQ 
          faqs={reviewsFAQs}
          title="Review FAQs"
          className="py-16 bg-gradient-to-b from-purple-900/20 to-black"
        />
      </main>

      <Footer />
    </div>
  );
}