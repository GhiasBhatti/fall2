import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import VideoGallery from "@/components/VideoGallery";
import QuoteForm from "@/components/QuoteForm";
import Footer from "@/components/Footer";
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";
import { useSEO, usePagePerformance } from "@/hooks/useSEO";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { FAQ } from "@/components/FAQ";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { 
  Car, 
  Users, 
  Star, 
  Heart, 
  PartyPopper, 
  Building2,
  ArrowRight,
  Quote 
} from "lucide-react";
import partyBusImage from "@assets/stock_images/luxury_party_bus_int_68646f3a.jpg";
import limousineImage from "@assets/stock_images/luxury_limousine_ext_55d719e9.jpg";

// SEO-optimized FAQ data
const homeFAQs = [
  {
    question: "What areas do you serve?",
    answer: "We provide luxury transportation services across New York, New Jersey, Connecticut, and Pennsylvania. Our service area covers major cities and surrounding areas in these states."
  },
  {
    question: "How far in advance should I book?",
    answer: "We recommend booking at least 2-3 weeks in advance for optimal vehicle selection. However, we can often accommodate last-minute requests based on availability."
  },
  {
    question: "What's included in your service?",
    answer: "Our service includes professional chauffeurs, fuel, insurance, and standard amenities. Pricing varies based on vehicle type, duration, and distance."
  },
  {
    question: "Do you offer airport transportation?",
    answer: "Yes! We provide reliable airport transfers with flight monitoring, meet & greet service, and luggage assistance to all major airports in our service area."
  },
  {
    question: "Are your vehicles inspected and insured?",
    answer: "Absolutely. All our vehicles undergo regular safety inspections and are fully insured. Our professional chauffeurs are licensed and background-checked."
  }
];

// Fleet Preview Component
function FleetPreview() {
  const featuredVehicles = [
    { 
      name: "Elite Party Bus", 
      capacity: "30-35", 
      image: partyBusImage, 
      type: "Party Bus"
    },
    { 
      name: "Luxury Limousine", 
      capacity: "8-10", 
      image: limousineImage, 
      type: "Limousine"
    }
  ];

  return (
    <section className="py-16 bg-muted/30" id="fleet">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Our Luxury Fleet
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover our premium collection of party buses and limousines, each equipped with top-tier amenities.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {featuredVehicles.map((vehicle, index) => (
            <Card key={index} className={`group card-manifest-hover card-glow-hover card-energy-flow overflow-hidden ${index === 0 ? 'animate-manifest-spiral' : 'animate-manifest-bounce'} animate-on-scroll animate-delay-${index * 300}`}>
              <div className="h-48 relative">
                <img 
                  src={vehicle.image}
                  alt={`${vehicle.name} luxury ${vehicle.type.toLowerCase()} interior with premium amenities for ${vehicle.capacity} passengers`}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                  decoding="async"
                  width="400"
                  height="192"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <div className="absolute top-4 left-4">
                  <Badge variant="secondary" className="bg-white/90 text-gray-900">
                    <Users className="w-3 h-3 mr-1" />
                    {vehicle.capacity} Passengers
                  </Badge>
                </div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-2 text-foreground">{vehicle.name}</h3>
                <Badge variant="outline" className="mb-3">{vehicle.type}</Badge>
                <p className="text-muted-foreground text-sm">
                  Premium amenities, professional service, and luxury comfort for your special events.
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Link href="/fleet" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <Button size="lg" data-testid="button-view-fleet">
              View Full Fleet
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}

// Services Preview Component
function ServicesPreview() {
  const featuredServices = [
    {
      icon: Heart,
      title: "Weddings",
      description: "Arrive in style on your special day with our luxurious wedding transportation."
    },
    {
      icon: PartyPopper,
      title: "Bachelor & Bachelorette",
      description: "Ultimate party experience with premium sound systems and professional service."
    },
    {
      icon: Building2,
      title: "Corporate Events",
      description: "Professional transportation solutions for business meetings and conferences."
    }
  ];

  return (
    <section className="py-16 bg-background" id="services">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Our Services
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Professional luxury transportation for all your special occasions and events.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {featuredServices.map((service, index) => (
            <Card key={index} className={`group card-premium-hover card-glow-hover card-pulse-glow text-center ${index % 3 === 0 ? 'animate-manifest-spiral' : index % 3 === 1 ? 'animate-manifest-bounce' : 'animate-manifest-pop'} animate-on-scroll animate-delay-${(index + 1) * 180}`}>
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors duration-300">
                  <service.icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-foreground">{service.title}</h3>
                <p className="text-muted-foreground">{service.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Link href="/services" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <Button size="lg" data-testid="button-view-services">
              View All Services
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}

// Reviews Preview Component  
function ReviewsPreview() {
  const featuredReviews = [
    {
      name: "Amy Finn-Szekula",
      rating: 5,
      text: "Amazing service! The limo was clean, and the driver was professional and punctual. Exceeded all our expectations for our wedding day.",
      event: "Wedding Transportation"
    },
    {
      name: "JoAnne Staten",
      rating: 5,
      text: "We hired the Fallimo party bus for our son's wedding. We could not be happier. The bus was a hit! Plus the driver was so professional.",
      event: "Wedding Reception"
    }
  ];

  return (
    <section className="py-16 bg-muted/30" id="reviews">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Customer Reviews
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            See what our satisfied customers say about their luxury transportation experience.
          </p>
          <div className="flex items-center justify-center gap-2 mt-4">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-6 h-6 text-yellow-400 fill-current" />
            ))}
            <span className="ml-2 text-lg font-semibold text-foreground">4.8</span>
            <span className="text-muted-foreground">/ 5 stars</span>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {featuredReviews.map((review, index) => (
            <Card key={index} className={`group card-manifest-hover card-glow-hover card-energy-flow ${index === 0 ? 'animate-manifest-spiral' : 'animate-manifest-bounce'} animate-on-scroll animate-delay-${index * 350}`}>
              <CardContent className="p-6">
                <div className="mb-4">
                  <Quote className="w-8 h-8 text-primary/30" />
                </div>
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-foreground mb-4 leading-relaxed">{review.text}</p>
                <div className="border-t border-border pt-4">
                  <div className="font-semibold text-foreground">{review.name}</div>
                  <div className="text-sm text-muted-foreground">{review.event}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Link href="/reviews" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <Button size="lg" data-testid="button-view-reviews">
              Read All Reviews
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}

export default function Home() {
  useIntersectionObserver();
  const seoData = useSEO('home');
  usePagePerformance();
  
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Breadcrumbs items={seoData.breadcrumbs || []} className="container mx-auto px-4 pt-4" />
      <main>
        <Hero />
        <FleetPreview />
        <ServicesPreview />
        <Features />
        <VideoGallery />
        <ReviewsPreview />
        <QuoteForm />
        
        <FAQ 
          faqs={homeFAQs}
          title="Frequently Asked Questions"
          className="py-16 bg-gradient-to-b from-purple-900/20 to-black"
        />
      </main>
      <Footer />
    </div>
  );
}