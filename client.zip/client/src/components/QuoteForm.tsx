import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, MapPin, Users, Clock, CheckCircle, AlertCircle } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function QuoteForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    eventDate: "",
    eventType: "",
    vehicleType: "",
    passengers: "",
    pickupLocation: "",
    destination: "",
    duration: "",
    message: ""
  });

  const { toast } = useToast();

  const submitQuoteMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const submitData = {
        ...data,
        passengers: data.passengers ? parseInt(data.passengers) : undefined
      };
      return await apiRequest('POST', '/api/quotes', submitData);
    },
    onSuccess: (response) => {
      console.log("Quote submission successful:", response);
      
      // Show success toast
      toast({
        title: "Quote Request Submitted!",
        description: "Thank you! We'll contact you within 1 hour with your custom quote.",
        variant: "default",
      });
      
      // Reset form
      setFormData({
        name: "",
        email: "",
        phone: "",
        eventDate: "",
        eventType: "",
        vehicleType: "",
        passengers: "",
        pickupLocation: "",
        destination: "",
        duration: "",
        message: ""
      });
    },
    onError: (error: any) => {
      console.error("Quote submission error:", error);
      toast({
        title: "Submission Failed",
        description: "We couldn't submit your quote request. Please try again or call us directly.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitQuoteMutation.mutate(formData);
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <section id="quote" className="py-16 bg-muted/30">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Get Your Free Quote
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Ready to book your luxury transportation? Fill out our quick quote form and 
            we'll get back to you within 1 hour with a custom quote for your event.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="w-5 h-5 text-primary" />
                <span>Request Custom Quote</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Contact Information */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="name">Full Name *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleChange("name", e.target.value)}
                      placeholder="Your full name"
                      required
                      data-testid="input-name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email Address *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleChange("email", e.target.value)}
                      placeholder="your@email.com"
                      required
                      data-testid="input-email"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleChange("phone", e.target.value)}
                      placeholder="(555) 123-4567"
                      required
                      data-testid="input-phone"
                    />
                  </div>
                </div>

                {/* Event Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="eventDate">Event Date *</Label>
                    <Input
                      id="eventDate"
                      type="date"
                      value={formData.eventDate}
                      onChange={(e) => handleChange("eventDate", e.target.value)}
                      required
                      data-testid="input-event-date"
                    />
                  </div>
                  <div>
                    <Label htmlFor="eventType">Event Type</Label>
                    <Select onValueChange={(value) => handleChange("eventType", value)}>
                      <SelectTrigger data-testid="select-event-type">
                        <SelectValue placeholder="Select event type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="wedding">Wedding</SelectItem>
                        <SelectItem value="bachelor-bachelorette">Bachelor/Bachelorette Party</SelectItem>
                        <SelectItem value="birthday">Birthday Party</SelectItem>
                        <SelectItem value="corporate">Corporate Event</SelectItem>
                        <SelectItem value="prom">Prom</SelectItem>
                        <SelectItem value="airport">Airport Transfer</SelectItem>
                        <SelectItem value="night-out">Night Out</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Vehicle & Passenger Info */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="vehicleType">Preferred Vehicle</Label>
                    <Select onValueChange={(value) => handleChange("vehicleType", value)}>
                      <SelectTrigger data-testid="select-vehicle-type">
                        <SelectValue placeholder="Select vehicle type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sprinter-12">12 Passenger Sprinter</SelectItem>
                        <SelectItem value="party-bus-24">24 Passenger Party Bus</SelectItem>
                        <SelectItem value="party-bus-50">50 Passenger Party Bus</SelectItem>
                        <SelectItem value="stretch-limo">Stretch Limousine</SelectItem>
                        <SelectItem value="exotic-limo">Exotic Limousine</SelectItem>
                        <SelectItem value="executive-shuttle">Executive Shuttle</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="passengers">Number of Passengers</Label>
                    <div className="relative">
                      <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="passengers"
                        type="number"
                        value={formData.passengers}
                        onChange={(e) => handleChange("passengers", e.target.value)}
                        placeholder="12"
                        className="pl-10"
                        min="1"
                        max="50"
                        data-testid="input-passengers"
                      />
                    </div>
                  </div>
                </div>

                {/* Location Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="pickupLocation">Pickup Location</Label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="pickupLocation"
                        value={formData.pickupLocation}
                        onChange={(e) => handleChange("pickupLocation", e.target.value)}
                        placeholder="Enter pickup address"
                        className="pl-10"
                        data-testid="input-pickup"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="destination">Destination</Label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="destination"
                        value={formData.destination}
                        onChange={(e) => handleChange("destination", e.target.value)}
                        placeholder="Enter destination"
                        className="pl-10"
                        data-testid="input-destination"
                      />
                    </div>
                  </div>
                </div>

                {/* Duration */}
                <div>
                  <Label htmlFor="duration">Estimated Duration</Label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="duration"
                      value={formData.duration}
                      onChange={(e) => handleChange("duration", e.target.value)}
                      placeholder="e.g., 4 hours, All day, Round trip"
                      className="pl-10"
                      data-testid="input-duration"
                    />
                  </div>
                </div>

                {/* Additional Message */}
                <div>
                  <Label htmlFor="message">Additional Details</Label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => handleChange("message", e.target.value)}
                    placeholder="Tell us more about your event, special requests, or any questions you have..."
                    rows={4}
                    data-testid="textarea-message"
                  />
                </div>

                {/* Submit Button */}
                <Button 
                  type="submit" 
                  size="lg" 
                  className="w-full" 
                  data-testid="button-submit-quote"
                  disabled={submitQuoteMutation.isPending}
                >
                  {submitQuoteMutation.isPending ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                      Submitting Quote...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Get My Free Quote
                    </>
                  )}
                </Button>

                <p className="text-sm text-muted-foreground text-center">
                  * We'll respond within 1 hour during business hours. 
                  For immediate assistance, call us at{" "}
                  <a href="tel:800-701-0024" className="text-primary hover:underline">
                    800-701-0024
                  </a>
                </p>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}