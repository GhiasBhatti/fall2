import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Users, Wifi, Music, Coffee } from "lucide-react";
import { useLocation } from "wouter";

const scrollToSection = (sectionId: string) => {
  const element = document.getElementById(sectionId);
  if (element) {
    element.scrollIntoView({ behavior: 'smooth' });
  }
};

const goToQuoteSection = (location: string, navigate: any) => {
  if (location === '/') {
    // Already on homepage, just scroll to quote section
    const element = document.getElementById('quote');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  } else {
    // Fast SPA navigation to homepage, then instant scroll to quote
    navigate('/');
    requestAnimationFrame(() => {
      const element = document.getElementById('quote');
      if (element) {
        element.scrollIntoView({ behavior: 'auto' }); // Instant scroll for speed
      }
    });
  }
};

interface FleetCardProps {
  title: string;
  description: string;
  image: string;
  capacity: string;
  features: string[];
  price?: string;
}

export default function FleetCard({ title, description, image, capacity, features, price }: FleetCardProps) {
  const [location, navigate] = useLocation();
  
  const handleViewDetails = () => {
    goToQuoteSection(location, navigate);
  };

  const handleBookNow = () => {
    goToQuoteSection(location, navigate);
  };

  return (
    <Card className="overflow-hidden card-premium-hover card-glow-hover card-energy-flow animate-manifest-pop animate-on-scroll">
      <div className="relative">
        <img 
          src={image} 
          alt={title}
          className="w-full h-64 object-cover"
        />
        <div className="absolute top-4 left-4">
          <Badge variant="secondary" className="bg-white/90 text-foreground">
            <Users className="w-3 h-3 mr-1" />
            {capacity}
          </Badge>
        </div>
        {price && (
          <div className="absolute top-4 right-4">
            <Badge className="bg-primary text-primary-foreground">
              {price}
            </Badge>
          </div>
        )}
      </div>
      
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold text-foreground mb-2" data-testid={`text-title-${title.toLowerCase().replace(/\s+/g, '-')}`}>
          {title}
        </h3>
        
        <p className="text-muted-foreground mb-4 line-clamp-2">
          {description}
        </p>
        
        <div className="flex flex-wrap gap-2 mb-6">
          {features.map((feature, index) => (
            <div key={index} className="flex items-center text-sm text-muted-foreground">
              {feature.includes('WiFi') && <Wifi className="w-3 h-3 mr-1" />}
              {feature.includes('Sound') && <Music className="w-3 h-3 mr-1" />}
              {feature.includes('Bar') && <Coffee className="w-3 h-3 mr-1" />}
              <span>{feature}</span>
            </div>
          ))}
        </div>
        
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={handleViewDetails}
            data-testid={`button-view-details-${title.toLowerCase().replace(/\s+/g, '-')}`}
          >
            View Details
          </Button>
          <Button 
            className="flex-1"
            onClick={handleBookNow}
            data-testid={`button-book-${title.toLowerCase().replace(/\s+/g, '-')}`}
          >
            Book Now
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}