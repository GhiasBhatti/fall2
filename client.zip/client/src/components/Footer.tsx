import { Button } from "@/components/ui/button";
import { Phone, Mail, MapPin, Facebook, Instagram, Youtube } from "lucide-react";
import { FaPinterest, FaTiktok } from "react-icons/fa";
import { SiYelp } from "react-icons/si";
import { useLocation } from "wouter";

const goToQuoteSection = (location: string, navigate: any) => {
  if (location === '/') {
    // Already on homepage, just scroll to quote section
    const element = document.getElementById('quote');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  } else {
    // Fast SPA navigation to homepage, then instant scroll to quote
    navigate('/');
    requestAnimationFrame(() => {
      const element = document.getElementById('quote');
      if (element) {
        element.scrollIntoView({ behavior: 'auto' }); // Instant scroll for speed
      }
    });
  }
};

const navigateToServices = (navigate: any) => {
  // Navigate to services page
  navigate('/services');
  // Scroll to top after navigation
  requestAnimationFrame(() => {
    window.scrollTo({ top: 0, behavior: 'auto' });
  });
};

export default function Footer() {
  const [location, navigate] = useLocation();
  return (
    <footer className="bg-foreground text-background">
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-2xl font-bold mb-4">
              <span className="text-primary">Fallimo</span>
            </h3>
            <p className="text-background/80 mb-4 leading-relaxed">
              Choose the Best, Leave the Rest! Premium luxury transportation services across 
              NJ, NY, CT & Philadelphia area. 24/7 availability, payment plans, and cashback offers available.
            </p>
            <div className="flex space-x-4">
              <a 
                href="https://www.facebook.com/2078449425543949" 
                className="text-background/60 hover:text-primary transition-colors"
                data-testid="link-facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a 
                href="https://www.instagram.com/fallimo.official" 
                className="text-background/60 hover:text-primary transition-colors"
                data-testid="link-instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a 
                href="https://www.pinterest.com/FallimoPartyBus/" 
                className="text-background/60 hover:text-primary transition-colors"
                data-testid="link-pinterest"
              >
                <FaPinterest className="w-5 h-5" />
              </a>
              <a 
                href="https://www.tiktok.com/@fallimopartybus" 
                className="text-background/60 hover:text-primary transition-colors"
                data-testid="link-tiktok"
              >
                <FaTiktok className="w-5 h-5" />
              </a>
              <a 
                href="https://www.yelp.com/biz/fallimo-denville" 
                className="text-background/60 hover:text-primary transition-colors"
                data-testid="link-yelp"
              >
                <SiYelp className="w-5 h-5" />
              </a>
              <a 
                href="https://www.youtube.com/@fallimopartybus" 
                className="text-background/60 hover:text-primary transition-colors"
                data-testid="link-youtube"
              >
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <a href="#home" className="text-background/80 hover:text-primary transition-colors" data-testid="footer-link-home">
                  Home
                </a>
              </li>
              <li>
                <a href="#fleet" className="text-background/80 hover:text-primary transition-colors" data-testid="footer-link-fleet">
                  Fleet
                </a>
              </li>
              <li>
                <a href="#services" className="text-background/80 hover:text-primary transition-colors" data-testid="footer-link-services">
                  Services
                </a>
              </li>
              <li>
                <a href="#reviews" className="text-background/80 hover:text-primary transition-colors" data-testid="footer-link-reviews">
                  Reviews
                </a>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Our Services</h4>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => navigateToServices(navigate)}
                  className="text-background/80 hover:text-primary transition-colors text-left"
                  data-testid="footer-link-party-bus"
                >
                  Party Bus Rental
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateToServices(navigate)}
                  className="text-background/80 hover:text-primary transition-colors text-left"
                  data-testid="footer-link-limousine"
                >
                  Limousine Service
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateToServices(navigate)}
                  className="text-background/80 hover:text-primary transition-colors text-left"
                  data-testid="footer-link-wedding"
                >
                  Wedding Transportation
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateToServices(navigate)}
                  className="text-background/80 hover:text-primary transition-colors text-left"
                  data-testid="footer-link-corporate"
                >
                  Corporate Events
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateToServices(navigate)}
                  className="text-background/80 hover:text-primary transition-colors text-left"
                  data-testid="footer-link-airport"
                >
                  Airport Transfers
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateToServices(navigate)}
                  className="text-background/80 hover:text-primary transition-colors text-left"
                  data-testid="footer-link-more"
                >
                  & more
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Us</h4>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-primary" />
                <div>
                  <a 
                    href="tel:800-701-0024" 
                    className="text-background/80 hover:text-primary transition-colors block"
                    data-testid="footer-link-phone1"
                  >
                    800-701-0024
                  </a>
                  <a 
                    href="tel:914-359-5463" 
                    className="text-background/80 hover:text-primary transition-colors block text-sm"
                    data-testid="footer-link-phone2"
                  >
                    914-359-5463
                  </a>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-primary" />
                <a 
                  href="mailto:info@fallimo.com" 
                  className="text-background/80 hover:text-primary transition-colors"
                  data-testid="footer-link-email"
                >
                  info@fallimo.com
                </a>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-primary mt-1" />
                <div className="text-background/80">
                  <a 
                    href="https://www.google.com/maps/dir/?api=1&destination=34+Watts+Ave,+Denville,+NJ+07834"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-medium hover:text-primary transition-colors cursor-pointer"
                    data-testid="footer-link-address"
                  >
                    34 Watts Ave, Denville, NJ 07834
                  </a>
                  <div className="text-sm">Serving NJ, NY, CT & Philadelphia area</div>
                  <div className="text-sm">24/7 Availability</div>
                </div>
              </div>
            </div>
            
            <Button 
              className="mt-4 w-full" 
              onClick={() => goToQuoteSection(location, navigate)}
              data-testid="button-footer-quote"
            >
              Get Quote Now
            </Button>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-background/20 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-background/60 text-sm mb-4 md:mb-0">
              © 2025 Fallimo Inc. All rights reserved.
            </div>
            <div className="flex space-x-6 text-sm">
              <a href="/privacy" className="text-background/60 hover:text-primary transition-colors">
                Privacy Policy
              </a>
              <a href="/terms" className="text-background/60 hover:text-primary transition-colors">
                Terms of Service
              </a>
              <a href="/disclaimer" className="text-background/60 hover:text-primary transition-colors">
                Disclaimer
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}