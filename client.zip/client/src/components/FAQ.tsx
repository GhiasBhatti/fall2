import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { useFAQSEO } from "@/hooks/useSEO";

interface FAQItem {
  question: string;
  answer: string;
}

interface FAQProps {
  faqs: FAQItem[];
  title?: string;
  className?: string;
}

export function FAQ({ faqs, title = "Frequently Asked Questions", className = "" }: FAQProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  
  // Add FAQ structured data for SEO
  useFAQSEO(faqs);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className={`w-full ${className}`}>
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-8 text-white">
          {title}
        </h2>
        <div className="max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <div 
              key={index} 
              className="border border-purple-500/20 rounded-lg mb-4 bg-black/40 backdrop-blur-sm hover-elevate"
            >
              <button
                className="w-full px-6 py-4 text-left flex justify-between items-center"
                onClick={() => toggleFAQ(index)}
                aria-expanded={openIndex === index}
                aria-controls={`faq-answer-${index}`}
                data-testid={`button-faq-${index}`}
              >
                <h3 className="font-semibold text-white text-lg">{faq.question}</h3>
                <ChevronDown 
                  className={`h-5 w-5 text-purple-400 transition-transform duration-200 ${
                    openIndex === index ? 'rotate-180' : ''
                  }`} 
                />
              </button>
              {openIndex === index && (
                <div 
                  id={`faq-answer-${index}`}
                  className="px-6 pb-4 text-gray-300 leading-relaxed"
                  data-testid={`text-faq-answer-${index}`}
                >
                  {faq.answer}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}