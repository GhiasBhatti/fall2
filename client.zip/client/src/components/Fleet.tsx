import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Car, Users, MapPin, Star, Crown, Sparkles } from "lucide-react";
import { useLocation } from "wouter";

const scrollToSection = (sectionId: string) => {
  const element = document.getElementById(sectionId);
  if (element) {
    element.scrollIntoView({ behavior: 'smooth' });
  }
};

const goToQuoteSection = (location: string, navigate: any) => {
  if (location === '/') {
    // Already on homepage, just scroll to quote section
    const element = document.getElementById('quote');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  } else {
    // Fast SPA navigation to homepage, then instant scroll to quote
    navigate('/');
    requestAnimationFrame(() => {
      const element = document.getElementById('quote');
      if (element) {
        element.scrollIntoView({ behavior: 'auto' }); // Instant scroll for speed
      }
    });
  }
};

export default function Fleet() {
  const [location, navigate] = useLocation();
  const fleetData = [
    // VINTAGE AND EXOTIC
    {
      category: "Vintage & Exotic",
      vehicles: [
        {
          name: "Rolls-Royce Austin Princess",
          capacity: 2,
          description: "For those with a taste for classic luxury, our Rolls-Royce Austin Princess provides a timeless experience. Perfect for weddings, historic tours, and VIP events, this vintage vehicle exudes sophistication. With handcrafted interiors and an iconic design, the Rolls-Royce Austin Princess is the ultimate choice for those looking to make a grand entrance.",
          features: ["Handcrafted interiors", "Iconic design", "Timeless experience", "Perfect for weddings", "Historic tours", "VIP events"],
          image: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/2022-10-01%20(1).jpg",
          isSpecial: true
        }
      ]
    },
    // LIMOUSINES
    {
      category: "Limousines",
      vehicles: [
        {
          name: "Chrysler 300 Limousine",
          capacity: "10-12",
          description: "Ideal for intimate gatherings such as weddings, corporate functions, and nights out, this limo features a sleek design, luxurious leather interiors, and an advanced sound system to ensure your group travels in style.",
          features: ["Sleek design", "Luxurious leather interiors", "Advanced sound system", "Intimate gatherings", "Corporate functions", "Stylish travel"],
          image: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/1278884_666306016712917_1705934844_o.jpg"
        },
        {
          name: "Escalade Jet Door Limo",
          capacity: 16,
          description: "The ultimate statement of luxury and style, this limo is perfect for making a dramatic entrance at proms, weddings, and upscale events. Enjoy luxurious seating, ambient lighting, and a top-tier entertainment system inside.",
          features: ["Ultimate luxury statement", "Dramatic entrance", "Luxurious seating", "Ambient lighting", "Top-tier entertainment", "Upscale events"],
          image: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/1278884_666306016712917_1705934844_o.jpg"
        },
        {
          name: "Lincoln Limo",
          capacity: 18,
          description: "This classic limo offers a luxurious travel experience, ideal for corporate events, anniversaries, and special celebrations, featuring plush leather seating, mood lighting, and an advanced sound system.",
          features: ["Classic luxury", "Plush leather seating", "Mood lighting", "Advanced sound system", "Corporate events", "Special celebrations"],
          image: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/1278884_666306016712917_1705934844_o.jpg"
        }
      ]
    },
    // PARTY BUSES - COMPACT
    {
      category: "Party Buses - Compact",
      vehicles: [
        {
          name: "Mercedes Sprinter Party Bus",
          capacity: 12,
          description: "Perfect for smaller groups looking for a lively atmosphere, this party bus boasts comfortable seating, vibrant LED lighting, and a state-of-the-art entertainment system, making it the perfect choice for birthday parties and city tours.",
          features: ["Comfortable seating", "Vibrant LED lighting", "State-of-the-art entertainment", "Lively atmosphere", "Birthday parties", "City tours"],
          image: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/815591DF-58F5-4431-8E4A-25C579E9BE25.jpeg"
        },
        {
          name: "Mercedes Party Bus",
          capacity: 15,
          description: "This stylish bus is perfect for birthdays, wine tours, and group celebrations. It features a chic interior with premium sound, mood lighting, and ample space for mingling and entertainment.",
          features: ["Chic interior", "Premium sound", "Mood lighting", "Ample mingling space", "Wine tours", "Group celebrations"],
          image: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/15%20Pass%20Sprinter%20Limo%20(4)-a4e6cf2.JPG"
        }
      ]
    },
    // PARTY BUSES - MEDIUM
    {
      category: "Party Buses - Medium",
      vehicles: [
        {
          name: "Party Bus with Dancing Pole and Bathroom",
          capacity: 24,
          description: "Designed for ultimate party experiences, this bus includes a dance pole, an on-board bathroom, and spacious interiors—perfect for bachelor/bachelorette parties and lively group events.",
          features: ["Dance pole", "On-board bathroom", "Spacious interiors", "Ultimate party experience", "Bachelor/bachelorette parties", "Lively group events"],
          image: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/24-25%20Pax%20Green.jpeg",
          isSpecial: true
        },
        {
          name: "Party Bus with Two Dancing Poles",
          capacity: 28,
          description: "Elevate your celebration with this 28-passenger party bus, featuring two dance poles, a premium audio system, and a vibrant atmosphere. It's the ideal choice for larger parties wanting a fun and memorable night out.",
          features: ["Two dance poles", "Premium audio system", "Vibrant atmosphere", "Larger parties", "Memorable night out", "Fun celebration"],
          image: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/20200310_001507-0f7d929.jpg",
          isSpecial: true
        }
      ]
    },
    // PARTY BUSES - EXECUTIVE
    {
      category: "Party Buses - Executive", 
      vehicles: [
        {
          name: "Executive Party Bus",
          capacity: 30,
          description: "Tailored for business events and corporate travel, this bus features elegant interiors, leather seating, and a high-end entertainment system, providing a refined environment for professional gatherings.",
          features: ["Elegant interiors", "Leather seating", "High-end entertainment", "Business events", "Corporate travel", "Professional gatherings"],
          image: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/30%20Pax%20Night.jpeg"
        },
        {
          name: "Party Bus with Dancing Pole and Bathroom",
          capacity: 30,
          description: "This bus caters to larger groups looking to party in style, featuring a dance pole, an on-board bathroom, and luxurious interiors for a fun and comfortable ride.",
          features: ["Dance pole", "On-board bathroom", "Luxurious interiors", "Larger groups", "Party in style", "Fun and comfortable ride"],
          image: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/2022-10-01%20(2).jpg",
          isSpecial: true
        },
        {
          name: "Executive Party Bus with Bathroom",
          capacity: 37,
          description: "Ideal for long trips and large group events, this executive party bus offers an on-board bathroom, reclining seats, and a premium entertainment system, making it perfect for those seeking comfort and convenience.",
          features: ["On-board bathroom", "Reclining seats", "Premium entertainment", "Long trips", "Large group events", "Comfort and convenience"],
          image: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/30%20Pax6.jpg"
        }
      ]
    },
    // LARGE CAPACITY VEHICLES
    {
      category: "Large Capacity Vehicles",
      vehicles: [
        {
          name: "Trolley Party Bus with Bathroom",
          capacity: "40-43",
          description: "This charming trolley bus is perfect for large group outings, offering spacious seating, a unique design, and an on-board bathroom. Ideal for city tours, weddings, and themed events.",
          features: ["Charming trolley design", "Spacious seating", "Unique design", "On-board bathroom", "City tours", "Themed events"],
          image: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/13254333_1194471667229680_3754061803636623742_.jpg"
        },
        {
          name: "Party Bus with Bathroom",
          capacity: 45,
          description: "This high-capacity bus transports large groups in style, featuring an on-board bathroom, advanced audio-visual systems, and ample space for everyone to enjoy the ride.",
          features: ["High-capacity", "On-board bathroom", "Advanced audio-visual systems", "Large groups", "Ample space", "Stylish transport"],
          image: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/11403447_1013187025358146_1621251141618130595_.jpg"
        },
        {
          name: "Party Bus with Dancing Pole and Bathroom",
          capacity: 50,
          description: "The ultimate choice for large-scale celebrations, this 50-passenger party bus includes a dance pole, an on-board bathroom, and a vibrant party atmosphere that ensures a memorable experience.",
          features: ["Dance pole", "On-board bathroom", "Vibrant party atmosphere", "Large-scale celebrations", "Ultimate choice", "Memorable experience"],
          image: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/30%20Pax%20with%20Pole%20%26%20Bath%206.jpeg",
          isSpecial: true
        },
        {
          name: "Setra Motorcoach",
          capacity: 55,
          description: "The Setra motorcoach epitomizes luxury for large groups, featuring reclining seats, on-board Wi-Fi, and a bathroom. It's ideal for long-distance travel, corporate retreats, and large events where comfort is key.",
          features: ["Reclining seats", "On-board Wi-Fi", "Bathroom", "Luxury for large groups", "Long-distance travel", "Corporate retreats"],
          image: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/33868372_1972835692726603_2796340721232117760_.jpg",
          isSpecial: true
        }
      ]
    }
  ];

  const getTotalVehicles = () => {
    return fleetData.reduce((total, category) => total + category.vehicles.length, 0);
  };

  const getCapacityBadgeColor = (capacity: number | string) => {
    const numCapacity = typeof capacity === 'string' ? parseInt(capacity.split('-')[0]) : capacity;
    if (numCapacity <= 12) return "default";
    if (numCapacity <= 20) return "secondary"; 
    if (numCapacity <= 35) return "destructive";
    return "default";
  };

  return (
    <section className="py-16 bg-muted/30" id="fleet">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
              <Car className="w-8 h-8 text-primary" />
            </div>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Our Luxury Fleet
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-6">
            Experience unmatched luxury with Fallimo's exquisite selection of {getTotalVehicles()} luxury vehicles, 
            meticulously designed to elevate any event. From intimate gatherings to grand celebrations, 
            our fleet delivers the perfect blend of elegance, comfort, and entertainment.
          </p>
          
          {/* Fleet Stats */}
          <div className="flex flex-wrap justify-center gap-6 mb-8">
            <div className="text-center">
              <div className="flex items-center justify-center text-primary mb-2">
                <Car className="w-6 h-6" />
              </div>
              <div className="text-2xl font-bold text-foreground">{getTotalVehicles()}</div>
              <div className="text-sm text-muted-foreground">Luxury Vehicles</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center text-primary mb-2">
                <Users className="w-6 h-6" />
              </div>
              <div className="text-2xl font-bold text-foreground">2-55</div>
              <div className="text-sm text-muted-foreground">Passengers</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center text-primary mb-2">
                <MapPin className="w-6 h-6" />
              </div>
              <div className="text-2xl font-bold text-foreground">24/7</div>
              <div className="text-sm text-muted-foreground">Service</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center text-primary mb-2">
                <Star className="w-6 h-6" />
              </div>
              <div className="text-2xl font-bold text-foreground">4.8/5</div>
              <div className="text-sm text-muted-foreground">Rating</div>
            </div>
          </div>
        </div>

        {/* Fleet Categories */}
        {fleetData.map((category, categoryIndex) => (
          <div key={categoryIndex} className="mb-16">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-foreground mb-2 flex items-center justify-center gap-2">
                {category.category === "Vintage & Exotic" && <Crown className="w-6 h-6 text-primary" />}
                {category.category.includes("Party Buses") && <Sparkles className="w-6 h-6 text-primary" />}
                {category.category === "Limousines" && <Star className="w-6 h-6 text-primary" />}
                {category.category === "Large Capacity Vehicles" && <Car className="w-6 h-6 text-primary" />}
                {category.category}
              </h3>
              <div className="w-20 h-1 bg-primary mx-auto"></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {category.vehicles.map((vehicle, index) => (
                <Card 
                  key={index} 
                  className={`hover-elevate transition-all duration-300 overflow-hidden ${
                    vehicle.isSpecial ? 'ring-2 ring-primary/20' : ''
                  }`}
                >
                  {/* Vehicle Image */}
                  <div className="h-48 relative overflow-hidden">
                    <img 
                      src={vehicle.image}
                      alt={`${vehicle.name} interior`}
                      className="w-full h-full object-cover"
                      loading="lazy"
                      decoding="async"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    
                    {/* Capacity Badge */}
                    <div className="absolute top-4 left-4">
                      <Badge 
                        variant={getCapacityBadgeColor(vehicle.capacity)}
                        className="text-sm font-medium"
                      >
                        <Users className="w-3 h-3 mr-1" />
                        {vehicle.capacity} {typeof vehicle.capacity === 'number' && vehicle.capacity === 1 ? 'Passenger' : 'Passengers'}
                      </Badge>
                    </div>

                    {/* Special Badge */}
                    {vehicle.isSpecial && (
                      <div className="absolute top-4 right-4">
                        <Badge variant="destructive" className="text-sm font-medium">
                          <Crown className="w-3 h-3 mr-1" />
                          Premium
                        </Badge>
                      </div>
                    )}

                    {/* Vehicle Name Overlay */}
                    <div className="absolute bottom-4 left-4 right-4">
                      <h4 className="text-xl font-bold text-white" data-testid={`text-vehicle-${vehicle.name.toLowerCase().replace(/\s+/g, '-')}`}>
                        {vehicle.name}
                      </h4>
                    </div>
                  </div>

                  <CardContent className="p-6">
                    {/* Description */}
                    <p className="text-muted-foreground mb-4 line-clamp-4 leading-relaxed">
                      {vehicle.description}
                    </p>

                    {/* Features */}
                    <div className="space-y-3 mb-6">
                      <h5 className="font-medium text-foreground text-sm">Premium Features:</h5>
                      <div className="flex flex-wrap gap-1">
                        {vehicle.features.slice(0, 4).map((feature, featureIndex) => (
                          <Badge 
                            key={featureIndex} 
                            variant="outline" 
                            className="text-xs"
                          >
                            {feature}
                          </Badge>
                        ))}
                        {vehicle.features.length > 4 && (
                          <Badge variant="outline" className="text-xs">
                            +{vehicle.features.length - 4} more
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        className="flex-1"
                        onClick={() => scrollToSection('videos')}
                        data-testid={`button-tour-${vehicle.name.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        See Tours
                      </Button>
                      <Button 
                        className="flex-1"
                        onClick={() => goToQuoteSection(location, navigate)}
                        data-testid={`button-book-${vehicle.name.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        Get Quote
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ))}

        {/* Bottom Call to Action */}
        <div className="text-center mt-16">
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-foreground mb-4">
                Can't Find What You're Looking For?
              </h3>
              <p className="text-lg text-muted-foreground mb-6 max-w-2xl mx-auto">
                Our fleet includes specialized vehicles for unique events. Contact us to discuss 
                your specific needs and we'll find the perfect luxury transportation solution.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg"
                  onClick={() => goToQuoteSection(location, navigate)}
                  data-testid="button-custom-quote"
                >
                  Request Custom Quote
                </Button>
                <Button 
                  variant="outline" 
                  size="lg"
                  onClick={() => {
                    window.open('tel:800-701-0024', '_self');
                  }}
                  data-testid="button-call-fleet"
                >
                  Call 800-701-0024
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}