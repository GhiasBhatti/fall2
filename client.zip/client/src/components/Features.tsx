import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, CreditCard, Video, DollarSign, Users, Shield } from "lucide-react";
import professionalDriverImage from "@assets/stock_images/professional_chauffe_6b1036d0.jpg";

const scrollToSection = (sectionId: string) => {
  const element = document.getElementById(sectionId);
  if (element) {
    element.scrollIntoView({ behavior: 'smooth' });
  }
};

export default function Features() {
  const features = [
    {
      icon: Clock,
      title: "24/7 Availability",
      description: "At Fallimo, we're available 24/7 to take your calls, answer questions, and book your party bus rental. Enjoy around-the-clock service for your convenience!"
    },
    {
      icon: CreditCard,
      title: "Flexible Payment Plans",
      description: "We believe everyone should enjoy luxury transportation without breaking the bank. Enjoy competitive, transparent prices with flexible payment plans to fit your budget."
    },
    {
      icon: Video,
      title: "See Before You Book",
      description: "Schedule your free video tour or personal garage visit today and SEE BEFORE YOU BOOK! Turn your event into an unforgettable experience with confidence."
    },
    {
      icon: DollarSign,
      title: "$100-$300 Cashback",
      description: "Only party bus and limo company with exclusive cashback offers ranging from $100 to $300. Get rewarded for choosing the best luxury transportation service!"
    },
    {
      icon: Users,
      title: "Special Discounts",
      description: "Special discounts available for veterans, medical staff, and teachers on all limo bus rentals. We honor those who serve our communities."
    },
    {
      icon: Shield,
      title: "Professional Service",
      description: "Professional chauffeurs with years of experience. Safe, reliable, and courteous service that ensures your event runs smoothly from start to finish."
    }
  ];

  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Why Choose Fallimo?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose the Best, Leave the Rest! Experience the difference with our exclusive 
            features and premium service that sets us apart from other transportation companies.
          </p>
        </div>

        {/* Professional Driver Image */}
        <div className="flex justify-center mb-12">
          <div className="relative">
            <img 
              src={professionalDriverImage} 
              alt="Professional chauffeur in uniform" 
              className="w-80 h-60 rounded-lg object-cover shadow-lg"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-lg"></div>
            <div className="absolute bottom-4 left-4 text-white">
              <div className="text-lg font-semibold">Professional Chauffeurs</div>
              <div className="text-sm opacity-90">Experienced • Courteous • Reliable</div>
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <Card key={index} className={`card-hover-lift card-glow-hover text-center animate-fade-in-scale animate-on-scroll animate-delay-${index * 100}`}>
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-8 h-8 text-primary" />
                  </div>
                  
                  <h3 className="text-xl font-semibold text-foreground mb-3">
                    {feature.title}
                  </h3>
                  
                  <p className="text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-12">
          <Card className="bg-primary/5 border-primary/20 card-hover-lift animate-fade-in-up animate-on-scroll animate-delay-600">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-foreground mb-4">
                Ready to Experience the Best?
              </h3>
              <p className="text-lg text-muted-foreground mb-6">
                Join thousands of satisfied customers who chose Fallimo for their luxury transportation needs. 
                Serving NJ, NY, CT & Philadelphia area with unmatched service and exclusive benefits.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg" 
                  onClick={() => scrollToSection('quote')}
                  data-testid="button-features-quote"
                >
                  Get Free Quote Now
                </Button>
                <Button 
                  variant="outline" 
                  size="lg"
                  onClick={() => {
                    window.open('tel:800-701-0024', '_self');
                  }}
                  data-testid="button-features-call"
                >
                  Call 800-701-0024
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}