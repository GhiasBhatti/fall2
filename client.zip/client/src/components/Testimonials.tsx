import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";
import testimonialsImage from "@assets/generated_images/Happy_customers_testimonial_f8a06be4.png";
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";

export default function Testimonials() {
  useIntersectionObserver();
  // Authentic Fallimo Customer Reviews from Google & Facebook
  const testimonials = [
    {
      name: "Amy Finn-Szekula",
      rating: 5,
      text: "Amazing service! The limo was clean, and the driver was professional and punctual. Exceeded all our expectations for our wedding day.",
      event: "Wedding Transportation"
    },
    {
      name: "Aliza Rojas", 
      rating: 5,
      text: "Wonderful customer service, from my initial contact. Bus was very clean. Driver very friendly. Definitely will contact you for another event. THANK YOU!!",
      event: "Birthday Party"
    },
    {
      name: "JoAnne Staten",
      rating: 5,
      text: "We hired the Fallimo 50 passenger party bus for our son's wedding. We could not be happier. The bus was a hit! Plus the driver was so professional and was in constant contact to make sure he was where we needed him.",
      event: "Wedding Reception"
    },
    {
      name: "Elysha Bembury",
      rating: 5,
      text: "Definitely would recommend this company to all! The 50-person party bus was perfect for our graduation party. Professional service from start to finish.",
      event: "Graduation Party"
    },
    {
      name: "Jeff Henderson",
      rating: 5,
      text: "Fantastic experience. Will definitely use Fallimo again. The vehicle was immaculate and the driver went above and beyond.",
      event: "Corporate Event"
    },
    {
      name: "Ilyssa Maisano",
      rating: 5,
      text: "Great service, so easy to book, driver was great and safe, bus was perfect! Made our night out absolutely memorable.",
      event: "Night Out"
    }
  ];

  return (
    <section className="py-16 bg-background" id="reviews">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            The Best Party Bus and Limo Service
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose the Best, Leave the Rest! Real customer reviews from Google and Facebook. 
            Join our satisfied clients who experienced the excellence that has made us the premier 
            luxury transportation service across NJ, NY, CT & Philadelphia area.
          </p>
        </div>

        {/* Customer Photo */}
        <div className="flex justify-center mb-12">
          <img 
            src={testimonialsImage} 
            alt="Happy customers celebrating" 
            className="w-64 h-64 rounded-full object-cover border-4 border-primary/20"
          />
        </div>

        {/* Rating Summary */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-2">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-6 h-6 text-primary fill-current" />
            ))}
          </div>
          <div className="text-2xl font-bold text-foreground">4.8 out of 5</div>
          <div className="text-muted-foreground">Based on 66+ reviews</div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className={`card-manifest-hover card-glow-hover card-pulse-glow ${index % 3 === 0 ? 'animate-manifest-spiral' : index % 3 === 1 ? 'animate-manifest-bounce' : 'animate-manifest-pop'} animate-on-scroll animate-delay-${index * 200}`}>
              <CardContent className="p-6">
                {/* Rating */}
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-primary fill-current" />
                  ))}
                </div>

                {/* Review Text */}
                <p className="text-muted-foreground mb-4 line-clamp-4 italic">
                  "{testimonial.text}"
                </p>

                {/* Customer Info */}
                <div className="border-t border-border pt-4">
                  <div className="font-semibold text-foreground" data-testid={`text-reviewer-${testimonial.name.toLowerCase().replace(/\s+/g, '-')}`}>
                    {testimonial.name}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {testimonial.event}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Cashback Offer */}
        <div className="mt-16 text-center">
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-foreground mb-4">
                Exclusive Cashback Offer
              </h3>
              <p className="text-lg text-muted-foreground mb-6">
                Get $100 to $300 cashback on your booking! We're the only party bus and 
                limo company offering this exclusive deal to our valued customers.
              </p>
              <div className="flex items-center justify-center space-x-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary">$100-300</div>
                  <div className="text-sm text-muted-foreground">Cashback</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}