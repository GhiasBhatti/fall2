import Fleet from '../Fleet';

export default function FleetExample() {
  return <Fleet />;
}