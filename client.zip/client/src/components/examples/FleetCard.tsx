import FleetCard from '../FleetCard';
import partyBusImage from "@assets/generated_images/Party_bus_interior_b9820753.png";

export default function FleetCardExample() {
  return (
    <div className="max-w-md">
      <FleetCard
        title="24 Passenger Party Bus"
        description="Ultimate party experience with dancing pole, LED lighting, premium sound system, and wet bar. Perfect for celebrations and special events."
        image={partyBusImage}
        capacity="Up to 24"
        features={["WiFi", "Sound System", "Wet Bar", "LED Lighting"]}
        price="From $150/hr"
      />
    </div>
  );
}