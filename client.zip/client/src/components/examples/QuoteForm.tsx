import QuoteForm from '../QuoteForm';

export default function QuoteFormExample() {
  return <QuoteForm />;
}