import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Building2, Users, PartyPopper, GraduationCap, Car } from "lucide-react";

const scrollToSection = (sectionId: string) => {
  const element = document.getElementById(sectionId);
  if (element) {
    element.scrollIntoView({ behavior: 'smooth' });
  }
};

export default function Services() {
  const handleServiceClick = (service: string) => {
    scrollToSection('quote');
  };

  const services = [
    {
      icon: Heart,
      title: "Weddings",
      description: "Arrive in style on your special day with our luxurious wedding limo service and Party Bus Hire. Perfect for intimate gatherings or grand celebrations with spacious interiors and top-notch amenities.",
      features: ["Rolls-Royce Austin Princess", "Bridal party transportation", "Wedding guest shuttles", "Photo opportunity vehicles"],
      cta: "Plan Your Wedding"
    },
    {
      icon: PartyPopper,
      title: "Bachelor & Bachelorette Parties",
      description: "Experience the ultimate bachelor/bachelorette party with our luxurious party bus hire. Enjoy spacious interiors, premium sound systems, dancing poles, and professional chauffeurs for an unforgettable celebration.",
      features: ["Dancing poles & bathrooms", "Premium sound systems", "LED lighting", "Safe transportation"],
      cta: "Book Party Bus"
    },
    {
      icon: GraduationCap,
      title: "Proms & School Events",
      description: "Make your prom night unforgettable with our Prom Party Bus and Limo services. Choose from sleek limousines or exciting party buses, making transportation part of the experience.",
      features: ["Safe & stylish transportation", "Group-friendly pricing", "Professional chauffeurs", "Memorable experience"],
      cta: "Book Prom Ride"
    },
    {
      icon: Users,
      title: "Birthdays & Celebrations",
      description: "From kid's birthdays to adult milestones, we cover it all! Experts in Bar/Bat Mitzvahs, Quinceañeras, Sweet 16s, and milestone birthdays. Contact us to plan the perfect birthday party bus hire.",
      features: ["Sweet 16 parties", "Bar/Bat Mitzvahs", "Quinceañeras", "Milestone birthdays"],
      cta: "Celebrate Your Day"
    },
    {
      icon: Building2,
      title: "Corporate Events",
      description: "Professional transportation solutions for business needs. Impress clients with our executive transportation, ensuring punctual arrivals for corporate meetings, conferences, and company events.",
      features: ["Executive transportation", "Conference shuttles", "Team building events", "Client entertainment"],
      cta: "Book Corporate"
    },
    {
      icon: Car,
      title: "Special Events & Sports",
      description: "We offer special deals for sports events like Olympics, World Cup, Masters Golf, concerts, casino events, and more. Perfect for family reunions, community events, and grand celebrations.",
      features: ["Sports events", "Concert transportation", "Casino trips", "Family reunions"],
      cta: "Book Special Event"
    }
  ];

  return (
    <section className="py-16 bg-muted/30" id="services">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Make Your Event Unforgettable
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Turn your event into an unforgettable experience with Fallimo's top-rated service. 
            Professional luxury transportation across NJ, NY, CT & Philadelphia area. 
            24/7 availability with payment plans and special discounts for veterans, medical staff, and teachers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <Card key={index} className="hover-elevate transition-all duration-300">
                <CardContent className="p-8">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <IconComponent className="w-6 h-6 text-primary" />
                      </div>
                    </div>
                    
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-foreground mb-3" data-testid={`text-service-${service.title.toLowerCase().replace(/\s+/g, '-')}`}>
                        {service.title}
                      </h3>
                      
                      <p className="text-muted-foreground mb-4 leading-relaxed">
                        {service.description}
                      </p>
                      
                      <ul className="text-sm text-muted-foreground mb-6 space-y-1">
                        {service.features.map((feature, idx) => (
                          <li key={idx} className="flex items-center">
                            <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></span>
                            {feature}
                          </li>
                        ))}
                      </ul>
                      
                      <Button 
                        variant="outline"
                        onClick={() => handleServiceClick(service.title)}
                        data-testid={`button-service-${service.title.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        {service.cta}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}