import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Phone, Menu, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import logoImage from "@assets/generated_images/Fallimo_transparent_logo_32485230.png";

import Gemini_Generated_Image_gacwbigacwbigacw__1_ from "@assets/Gemini_Generated_Image_gacwbigacwbigacw (1).png";

import Gemini_Generated_Image_gacwbigacwbigacw__1__removebg_preview from "@assets/Gemini_Generated_Image_gacwbigacwbigacw__1_-removebg-preview.png";

import Gemini_Generated_Image_gacwbigacwbigacw__1__removebg_preview__1_ from "@assets/Gemini_Generated_Image_gacwbigacwbigacw__1_-removebg-preview (1).png";

const scrollToSection = (sectionId: string) => {
  const element = document.getElementById(sectionId);
  if (element) {
    element.scrollIntoView({ behavior: 'smooth' });
  }
};

const goToQuoteSection = (location: string, navigate: any) => {
  if (location === '/') {
    // Already on homepage, just scroll to quote section
    scrollToSection('quote');
  } else {
    // Fast SPA navigation to homepage, then instant scroll to quote
    navigate('/');
    requestAnimationFrame(() => {
      const element = document.getElementById('quote');
      if (element) {
        element.scrollIntoView({ behavior: 'auto' }); // Instant scroll for speed
      }
    });
  }
};

const navigateToPage = (path: string, navigate: any) => {
  // Navigate to the page
  navigate(path);
  // Scroll to top after navigation
  requestAnimationFrame(() => {
    window.scrollTo({ top: 0, behavior: 'auto' });
  });
};

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location, navigate] = useLocation();


  return (
    <header className="bg-background border-b border-border sticky top-0 z-50">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-24">
          {/* Logo */}
          <div className="h-full flex items-center">
            <img 
              src={Gemini_Generated_Image_gacwbigacwbigacw__1__removebg_preview__1_} 
              alt="Fallimo Luxury Transportation logo" 
              className="h-full w-auto block mt-[0px] mb-[0px]"
              style={{ height: '100%' }}
            />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => navigateToPage('/', navigate)}
              className={`transition-colors ${
                location === '/' 
                  ? 'text-primary font-semibold' 
                  : 'text-foreground hover:text-primary'
              }`} 
              data-testid="link-home"
            >
              Home
            </button>
            <button
              onClick={() => navigateToPage('/fleet', navigate)}
              className={`transition-colors ${
                location === '/fleet' 
                  ? 'text-primary font-semibold' 
                  : 'text-foreground hover:text-primary'
              }`} 
              data-testid="link-fleet"
            >
              Fleet
            </button>
            <button
              onClick={() => navigateToPage('/services', navigate)}
              className={`transition-colors ${
                location === '/services' 
                  ? 'text-primary font-semibold' 
                  : 'text-foreground hover:text-primary'
              }`} 
              data-testid="link-services"
            >
              Services
            </button>
            <button
              onClick={() => navigateToPage('/reviews', navigate)}
              className={`transition-colors ${
                location === '/reviews' 
                  ? 'text-primary font-semibold' 
                  : 'text-foreground hover:text-primary'
              }`} 
              data-testid="link-reviews"
            >
              Reviews
            </button>
          </nav>

          {/* Phone & CTA */}
          <div className="hidden md:flex items-center space-x-4">
            <a 
              href="tel:800-701-0024" 
              className="flex items-center text-foreground hover:text-primary transition-colors"
              data-testid="link-phone"
            >
              <Phone className="w-4 h-4 mr-2" />
              <span className="font-medium">800-701-0024</span>
            </a>
            <Button onClick={() => goToQuoteSection(location, navigate)} data-testid="button-quote">Get Free Quote</Button>
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="button-mobile-menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-border">
            <nav className="flex flex-col space-y-4">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  navigateToPage('/', navigate);
                }}
                className={`transition-colors text-left ${
                  location === '/' 
                    ? 'text-primary font-semibold' 
                    : 'text-foreground hover:text-primary'
                }`} 
                data-testid="mobile-link-home"
              >
                Home
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  navigateToPage('/fleet', navigate);
                }}
                className={`transition-colors text-left ${
                  location === '/fleet' 
                    ? 'text-primary font-semibold' 
                    : 'text-foreground hover:text-primary'
                }`} 
                data-testid="mobile-link-fleet"
              >
                Fleet
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  navigateToPage('/services', navigate);
                }}
                className={`transition-colors text-left ${
                  location === '/services' 
                    ? 'text-primary font-semibold' 
                    : 'text-foreground hover:text-primary'
                }`} 
                data-testid="mobile-link-services"
              >
                Services
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  navigateToPage('/reviews', navigate);
                }}
                className={`transition-colors text-left ${
                  location === '/reviews' 
                    ? 'text-primary font-semibold' 
                    : 'text-foreground hover:text-primary'
                }`} 
                data-testid="mobile-link-reviews"
              >
                Reviews
              </button>
              <div className="pt-4 border-t border-border">
                <a 
                  href="tel:800-701-0024" 
                  className="flex items-center text-foreground hover:text-primary transition-colors mb-4"
                  data-testid="mobile-link-phone"
                >
                  <Phone className="w-4 h-4 mr-2" />
                  <span className="font-medium">800-701-0024</span>
                </a>
                <Button 
                  className="w-full" 
                  onClick={() => {
                    goToQuoteSection(location, navigate);
                    setMobileMenuOpen(false);
                  }} 
                  data-testid="mobile-button-quote"
                >
                  Get Free Quote
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}