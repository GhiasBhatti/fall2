import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Eye, Video } from "lucide-react";
import { useLocation } from "wouter";

const scrollToSection = (sectionId: string) => {
  const element = document.getElementById(sectionId);
  if (element) {
    element.scrollIntoView({ behavior: 'smooth' });
  }
};

const goToQuoteSection = (location: string, navigate: any) => {
  if (location === '/') {
    // Already on homepage, just scroll to quote section
    const element = document.getElementById('quote');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  } else {
    // Fast SPA navigation to homepage, then instant scroll to quote
    navigate('/');
    requestAnimationFrame(() => {
      const element = document.getElementById('quote');
      if (element) {
        element.scrollIntoView({ behavior: 'auto' }); // Instant scroll for speed
      }
    });
  }
};

export default function VideoGallery() {
  const [location, navigate] = useLocation();
  const fleetVideos = [
    {
      title: "12 Passengers Mercedes Party Bus",
      capacity: "12 Passengers",
      description: "See inside our 12-passenger Mercedes party bus featuring comfortable seating, LED lighting, and premium entertainment systems perfect for smaller groups and intimate celebrations.",
      videoId: "qe5vPK1lUXc",
      thumbnail: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/12%20Pax%20Sprinter%20In%201.jpg",
      tourId: "12-passenger-mercedes-party-bus"
    },
    {
      title: "15 Passengers Mercedes Party Bus",
      capacity: "15 Passengers",
      description: "Tour our 15-passenger Mercedes Sprinter party bus with spacious interiors, wet bar, roof features, and elegant lighting systems for your special events.",
      videoId: "Gq18oFTIpaQ",
      thumbnail: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/15%20Pass%20Sprinter%20Limo%20(2).JPG",
      tourId: "15-passenger-mercedes-party-bus"
    },
    {
      title: "24 Passenger Party Bus with Pole and Bathroom",
      capacity: "24 Passengers",
      description: "Experience our 24-passenger party bus featuring a dancing pole, on-board bathroom, premium sound systems, and vibrant party lighting for ultimate celebrations.",
      videoId: "gu5Kqvp_TgQ",
      thumbnail: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/24%20Pass%20Party%20Bus%208.jpg",
      tourId: "24-passenger-party-bus-with-pole-bathroom"
    },
    {
      title: "28 Passengers Party Bus with 2 Poles",
      capacity: "28 Passengers",
      description: "Experience our 28-passenger party bus featuring two dancing poles, mood changing lights, premium audio system, and vibrant party atmosphere perfect for larger celebrations.",
      videoId: "_1o7EeH7tmc",
      thumbnail: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/28%20Pax.jpg",
      tourId: "28-passenger-party-bus-two-poles"
    },
    {
      title: "30 Passengers Executive Party Bus",
      capacity: "30 Passengers",
      description: "Tour our 30-passenger executive party bus with elegant interiors, leather seating, and high-end entertainment system providing a refined environment for professional gatherings.",
      videoId: "_55KCIIuPNw",
      thumbnail: "https://img1.wsimg.com/isteam/ip/a57a4e26-e054-4631-900e-6af1f5faf00f/30%20Pax%20Ext.jpg",
      tourId: "30-passenger-executive-party-bus"
    }
  ];


  const handleScheduleTour = () => {
    // Scroll to quote form and focus the message field for tour requests
    scrollToSection('quote');
  };

  return (
    <section className="py-16 bg-background" id="videos">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
              <Video className="w-8 h-8 text-primary" />
            </div>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            See Before You Book
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Schedule your free video tour or personal garage visit today! Explore our luxury fleet 
            through authentic vehicle tours and see exactly what you're getting. Turn your event 
            into an unforgettable experience with confidence.
          </p>
        </div>

        {/* Fleet Video Gallery */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {fleetVideos.map((video, index) => (
            <Card key={index} className={`card-manifest-hover card-glow-hover card-energy-flow overflow-hidden ${index % 2 === 0 ? 'animate-manifest-spiral' : 'animate-manifest-bounce'} animate-on-scroll animate-delay-${index * 250}`}>
              {/* YouTube Video Embed */}
              <div className="relative">
                <div className="relative h-0 pb-[56.25%] overflow-hidden">
                  <iframe
                    className="absolute top-0 left-0 w-full h-full"
                    src={`https://www.youtube.com/embed/${video.videoId}?rel=0&modestbranding=1`}
                    title={video.title}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowFullScreen
                    data-testid={`video-${video.tourId}`}
                  />
                </div>
                
                {/* Capacity Badge */}
                <div className="absolute top-3 left-3 bg-primary text-primary-foreground text-sm font-medium px-3 py-1 rounded-full z-10">
                  {video.capacity}
                </div>
              </div>
              
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-foreground mb-3" data-testid={`text-video-${video.tourId}`}>
                  {video.title}
                </h3>
                
                <p className="text-muted-foreground mb-4 line-clamp-3">
                  {video.description}
                </p>
                
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={handleScheduleTour}
                    data-testid={`button-request-tour-${video.tourId}`}
                  >
                    <Video className="w-4 h-4 mr-2" />
                    Request Personal Tour
                  </Button>
                  <Button 
                    className="flex-1"
                    onClick={() => goToQuoteSection(location, navigate)}
                    data-testid={`button-book-${video.tourId}`}
                  >
                    Get Quote
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <Card className="bg-muted/30 border-muted">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-foreground mb-4">
                Want to See More Vehicles?
              </h3>
              <p className="text-lg text-muted-foreground mb-6">
                We have luxury vehicles across all categories in our fleet! Request a complete video tour 
                of any vehicle or schedule a personal garage visit to see them all.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg"
                  onClick={handleScheduleTour}
                  data-testid="button-request-all-videos"
                >
                  Request All Videos
                </Button>
                <Button 
                  variant="outline" 
                  size="lg"
                  onClick={() => scrollToSection('fleet')}
                  data-testid="button-view-full-fleet"
                >
                  View Full Fleet
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}