import { useEffect } from 'react';
import { 
  SEOConfig, 
  seoConfigs, 
  updateMetaTags, 
  addStructuredData,
  generateOrganizationSchema,
  generateServiceSchema,
  generateWebsiteSchema,
  generateBreadcrumbSchema,
  generateFAQSchema 
} from '@/lib/seo';

// WordPress-like SEO Hook
export const useSEO = (pageKey: keyof typeof seoConfigs, customConfig?: Partial<SEOConfig>) => {
  useEffect(() => {
    const config = { ...seoConfigs[pageKey], ...customConfig };
    
    // Update meta tags
    updateMetaTags(config);

    // Add page-specific structured data
    addStructuredData('organization-schema', generateOrganizationSchema());
    addStructuredData('website-schema', generateWebsiteSchema());
    
    if (pageKey === 'services') {
      addStructuredData('service-schema', generateServiceSchema());
    }

    // Add breadcrumb schema if breadcrumbs exist
    if (config.breadcrumbs) {
      addStructuredData('breadcrumb-schema', generateBreadcrumbSchema(config.breadcrumbs));
    }

    // Add custom schema if provided
    if (config.schema) {
      addStructuredData('page-schema', config.schema);
    }

  }, [pageKey, customConfig]);

  return seoConfigs[pageKey];
};

// Hook for FAQ sections
export const useFAQSEO = (faqs: Array<{question: string, answer: string}>) => {
  useEffect(() => {
    if (faqs.length > 0) {
      addStructuredData('faq-schema', generateFAQSchema(faqs));
    }
  }, [faqs]);
};

// Performance optimization hook
export const usePagePerformance = () => {
  useEffect(() => {
    // Lazy load images
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target as HTMLImageElement;
          img.src = img.dataset.src || '';
          img.classList.remove('lazy');
          observer.unobserve(img);
        }
      });
    });

    images.forEach(img => imageObserver.observe(img));

    // Preload critical resources
    const preloadCriticalResources = () => {
      // Preload hero images
      const heroImages = [
        '/assets/zxc_1758692852687-BkKDpuBw.png'
      ];
      
      heroImages.forEach(src => {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.as = 'image';
        link.href = src;
        document.head.appendChild(link);
      });
    };

    preloadCriticalResources();

    return () => {
      images.forEach(img => imageObserver.unobserve(img));
    };
  }, []);
};