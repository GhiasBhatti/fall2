import { useEffect, useRef } from 'react';

export function useIntersectionObserver() {
  const hasInitialized = useRef(false);

  useEffect(() => {
    if (hasInitialized.current) return;
    hasInitialized.current = true;

    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const element = entry.target as HTMLElement;
          
          // Remove the initial hidden state and trigger animation
          element.style.opacity = '1';
          element.style.transform = 'translateY(0)';
          
          // Remove the animate-on-scroll class to prevent re-triggering
          element.classList.remove('animate-on-scroll');
          
          // Stop observing this element
          observer.unobserve(element);
        }
      });
    };

    const observer = new IntersectionObserver(observerCallback, {
      root: null,
      rootMargin: '0px 0px -100px 0px', // Trigger animation slightly before element is fully visible
      threshold: 0.1
    });

    // Find all elements with animate-on-scroll class
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    
    animatedElements.forEach((element) => {
      observer.observe(element);
    });

    // Cleanup function
    return () => {
      observer.disconnect();
    };
  }, []);
}