import { MailService } from '@sendgrid/mail';
import type { QuoteRequest } from '@shared/schema';

const hasEmailConfig = !!(
  process.env.SENDGRID_API_KEY && 
  process.env.SENDGRID_FROM_EMAIL && 
  process.env.QUOTE_NOTIFICATION_EMAIL
);

let mailService: MailService | null = null;

if (hasEmailConfig) {
  mailService = new MailService();
  mailService.setApiKey(process.env.SENDGRID_API_KEY!);
  console.log('Email service configured with SendGrid');
} else {
  console.warn('Email service not configured - email notifications will be disabled');
  console.warn('To enable emails, set: SENDGRID_API_KEY, SENDGRID_FROM_EMAIL, QUOTE_NOTIFICATION_EMAIL');
}

interface EmailParams {
  to: string;
  from: string;
  subject: string;
  text?: string;
  html?: string;
}

export async function sendEmail(params: EmailParams): Promise<boolean> {
  if (!mailService || !hasEmailConfig) {
    console.log('Email service not configured - skipping email to:', params.to);
    return false;
  }

  try {
    const emailData: any = {
      to: params.to,
      from: params.from,
      subject: params.subject,
    };
    
    if (params.text) {
      emailData.text = params.text;
    }
    
    if (params.html) {
      emailData.html = params.html;
    }
    
    await mailService.send(emailData);
    return true;
  } catch (error) {
    console.error('SendGrid email error:', error);
    return false;
  }
}

export async function sendQuoteNotification(quoteRequest: QuoteRequest): Promise<boolean> {
  const subject = `New Quote Request from ${quoteRequest.name}`;
  
  const htmlContent = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #B8860B;">New Quote Request - Fallimo Luxury Transportation</h2>
      
      <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3 style="margin-top: 0;">Customer Information</h3>
        <p><strong>Name:</strong> ${quoteRequest.name}</p>
        <p><strong>Email:</strong> ${quoteRequest.email}</p>
        <p><strong>Phone:</strong> ${quoteRequest.phone}</p>
      </div>

      <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3 style="margin-top: 0;">Event Details</h3>
        <p><strong>Event Date:</strong> ${quoteRequest.eventDate}</p>
        ${quoteRequest.eventType ? `<p><strong>Event Type:</strong> ${quoteRequest.eventType}</p>` : ''}
        ${quoteRequest.vehicleType ? `<p><strong>Vehicle Type:</strong> ${quoteRequest.vehicleType}</p>` : ''}
        ${quoteRequest.passengers ? `<p><strong>Number of Passengers:</strong> ${quoteRequest.passengers}</p>` : ''}
        ${quoteRequest.duration ? `<p><strong>Duration:</strong> ${quoteRequest.duration}</p>` : ''}
      </div>

      ${quoteRequest.pickupLocation || quoteRequest.destination ? `
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0;">Location Details</h3>
          ${quoteRequest.pickupLocation ? `<p><strong>Pickup Location:</strong> ${quoteRequest.pickupLocation}</p>` : ''}
          ${quoteRequest.destination ? `<p><strong>Destination:</strong> ${quoteRequest.destination}</p>` : ''}
        </div>
      ` : ''}

      ${quoteRequest.message ? `
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0;">Additional Message</h3>
          <p>${quoteRequest.message}</p>
        </div>
      ` : ''}

      <div style="margin-top: 30px; padding: 20px; border: 2px solid #B8860B; border-radius: 8px;">
        <p style="margin: 0;"><strong>Quote Request ID:</strong> ${quoteRequest.id}</p>
        <p style="margin: 10px 0 0 0;"><strong>Submitted:</strong> ${new Date(quoteRequest.createdAt).toLocaleString()}</p>
      </div>

      <p style="color: #666; margin-top: 30px; font-size: 14px;">
        This is an automated notification from your Fallimo website. Please respond to the customer promptly.
      </p>
    </div>
  `;

  const textContent = `
New Quote Request - Fallimo Luxury Transportation

Customer Information:
Name: ${quoteRequest.name}
Email: ${quoteRequest.email}
Phone: ${quoteRequest.phone}

Event Details:
Event Date: ${quoteRequest.eventDate}
${quoteRequest.eventType ? `Event Type: ${quoteRequest.eventType}` : ''}
${quoteRequest.vehicleType ? `Vehicle Type: ${quoteRequest.vehicleType}` : ''}
${quoteRequest.passengers ? `Number of Passengers: ${quoteRequest.passengers}` : ''}
${quoteRequest.duration ? `Duration: ${quoteRequest.duration}` : ''}

${quoteRequest.pickupLocation ? `Pickup Location: ${quoteRequest.pickupLocation}` : ''}
${quoteRequest.destination ? `Destination: ${quoteRequest.destination}` : ''}

${quoteRequest.message ? `Additional Message: ${quoteRequest.message}` : ''}

Quote Request ID: ${quoteRequest.id}
Submitted: ${new Date(quoteRequest.createdAt).toLocaleString()}
  `;

  return await sendEmail({
    to: process.env.QUOTE_NOTIFICATION_EMAIL!,
    from: process.env.SENDGRID_FROM_EMAIL!,
    subject,
    html: htmlContent,
    text: textContent
  });
}