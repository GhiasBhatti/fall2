import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertQuoteRequestSchema } from "@shared/schema";
import { z } from "zod";
import { sendQuoteNotification } from "./email";

export async function registerRoutes(app: Express): Promise<Server> {
  // Quote request endpoints
  app.post("/api/quotes", async (req, res) => {
    try {
      // Validate request body
      const validation = insertQuoteRequestSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({
          error: "Invalid quote request data",
          details: validation.error.errors
        });
      }

      // Create quote request
      const quoteRequest = await storage.createQuoteRequest(validation.data);
      
      // Send email notification (don't block the response)
      sendQuoteNotification(quoteRequest).catch(error => {
        console.error("Failed to send email notification:", error);
      });
      
      res.status(201).json({
        success: true,
        quoteRequest: {
          id: quoteRequest.id,
          name: quoteRequest.name,
          email: quoteRequest.email,
          eventDate: quoteRequest.eventDate,
          eventType: quoteRequest.eventType,
          vehicleType: quoteRequest.vehicleType,
          createdAt: quoteRequest.createdAt
        }
      });
    } catch (error) {
      console.error("Error creating quote request:", error);
      res.status(500).json({
        error: "Failed to submit quote request"
      });
    }
  });

  // Get all quote requests (admin endpoint)
  app.get("/api/quotes", async (req, res) => {
    try {
      const quotes = await storage.getAllQuoteRequests();
      res.json({ quotes });
    } catch (error) {
      console.error("Error fetching quote requests:", error);
      res.status(500).json({
        error: "Failed to fetch quote requests"
      });
    }
  });

  // Get specific quote request
  app.get("/api/quotes/:id", async (req, res) => {
    try {
      const quote = await storage.getQuoteRequest(req.params.id);
      if (!quote) {
        return res.status(404).json({
          error: "Quote request not found"
        });
      }
      res.json({ quote });
    } catch (error) {
      console.error("Error fetching quote request:", error);
      res.status(500).json({
        error: "Failed to fetch quote request"
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
