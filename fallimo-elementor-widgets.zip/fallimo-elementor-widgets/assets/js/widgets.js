/**
 * Fallimo Elementor Widgets JavaScript
 */

(function($) {
    'use strict';

    // FAQ Accordion Toggle
    $(document).on('click', '.faq-toggle', function() {
        const target = $(this).data('target');
        const answer = $('#' + target);
        
        $(this).toggleClass('active');
        answer.toggleClass('active hidden');
    });

    // Quote Form Submission
    $(document).on('submit', '.fallimo-quote-form-element', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const messageDiv = form.find('.fallimo-quote-message');
        const submitBtn = form.find('button[type="submit"]');
        const successMessage = form.data('success-message') || 'Thank you! Your quote request has been submitted successfully.';
        
        // Disable submit button
        submitBtn.prop('disabled', true).text('Submitting...');
        
        // Collect form data
        const formData = {
            name: form.find('[name="name"]').val(),
            email: form.find('[name="email"]').val(),
            phone: form.find('[name="phone"]').val(),
            eventDate: form.find('[name="eventDate"]').val(),
            eventType: form.find('[name="eventType"]').val(),
            vehicleType: form.find('[name="vehicleType"]').val(),
            passengers: form.find('[name="passengers"]').val(),
            duration: form.find('[name="duration"]').val(),
            pickupLocation: form.find('[name="pickupLocation"]').val(),
            destination: form.find('[name="destination"]').val(),
            message: form.find('[name="message"]').val()
        };
        
        // Send AJAX request
        $.ajax({
            url: fallimoAjax.rest_url + 'quotes',
            type: 'POST',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            success: function(response) {
                messageDiv.removeClass('hidden error').addClass('success');
                messageDiv.text(successMessage);
                form[0].reset();
                
                // Scroll to message
                $('html, body').animate({
                    scrollTop: messageDiv.offset().top - 100
                }, 500);
            },
            error: function(xhr) {
                let errorMessage = 'An error occurred. Please try again.';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                }
                messageDiv.removeClass('hidden success').addClass('error');
                messageDiv.text(errorMessage);
            },
            complete: function() {
                submitBtn.prop('disabled', false).text('Submit Quote Request');
            }
        });
    });

    // Smooth scroll for anchor links
    $(document).on('click', 'a[href^="#"]', function(e) {
        const href = $(this).attr('href');
        if (href === '#' || !href) return;
        
        const target = $(href);
        if (target.length) {
            e.preventDefault();
            $('html, body').animate({
                scrollTop: target.offset().top - 80
            }, 800);
        }
    });

    // Elementor Preview Mode - Reinitialize on preview update
    if (typeof elementorFrontend !== 'undefined') {
        $(window).on('elementor/frontend/init', function() {
            elementorFrontend.hooks.addAction('frontend/element_ready/widget', function($scope) {
                // Reinitialize FAQ toggles
                $scope.find('.faq-toggle').off('click').on('click', function() {
                    const target = $(this).data('target');
                    const answer = $('#' + target);
                    
                    $(this).toggleClass('active');
                    answer.toggleClass('active hidden');
                });
            });
        });
    }

})(jQuery);
