<?php
/**
 * Plugin Name: Fallimo Elementor Widgets
 * Description: Custom Elementor widgets for Fallimo luxury transportation theme with full drag-and-drop editing capabilities
 * Version: 1.0.0
 * Author: Fallimo
 * Text Domain: fallimo-elementor
 * Domain Path: /languages
 * Elementor tested up to: 3.24
 * Elementor Pro tested up to: 3.24
 */

if (!defined('ABSPATH')) {
    exit;
}

define('FALLIMO_ELEMENTOR_VERSION', '1.0.0');
define('FALLIMO_ELEMENTOR_DIR', plugin_dir_path(__FILE__));
define('FALLIMO_ELEMENTOR_URL', plugin_dir_url(__FILE__));

final class Fallimo_Elementor_Widgets {
    
    private static $_instance = null;
    
    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct() {
        add_action('plugins_loaded', [$this, 'init']);
    }
    
    public function init() {
        if (!did_action('elementor/loaded')) {
            add_action('admin_notices', [$this, 'admin_notice_missing_elementor']);
            return;
        }
        
        add_action('elementor/widgets/register', [$this, 'register_widgets']);
        add_action('elementor/frontend/after_enqueue_styles', [$this, 'enqueue_styles']);
        add_action('elementor/frontend/after_register_scripts', [$this, 'enqueue_scripts']);
    }
    
    public function admin_notice_missing_elementor() {
        if (isset($_GET['activate'])) unset($_GET['activate']);
        
        $message = sprintf(
            esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'fallimo-elementor'),
            '<strong>' . esc_html__('Fallimo Elementor Widgets', 'fallimo-elementor') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'fallimo-elementor') . '</strong>'
        );
        
        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }
    
    public function register_widgets($widgets_manager) {
        require_once(FALLIMO_ELEMENTOR_DIR . 'widgets/hero-widget.php');
        require_once(FALLIMO_ELEMENTOR_DIR . 'widgets/fleet-widget.php');
        require_once(FALLIMO_ELEMENTOR_DIR . 'widgets/services-widget.php');
        require_once(FALLIMO_ELEMENTOR_DIR . 'widgets/testimonials-widget.php');
        require_once(FALLIMO_ELEMENTOR_DIR . 'widgets/features-widget.php');
        require_once(FALLIMO_ELEMENTOR_DIR . 'widgets/faq-widget.php');
        require_once(FALLIMO_ELEMENTOR_DIR . 'widgets/video-gallery-widget.php');
        require_once(FALLIMO_ELEMENTOR_DIR . 'widgets/quote-form-widget.php');
        require_once(FALLIMO_ELEMENTOR_DIR . 'widgets/footer-widget.php');
        
        $widgets_manager->register(new \Fallimo_Elementor_Hero_Widget());
        $widgets_manager->register(new \Fallimo_Elementor_Fleet_Widget());
        $widgets_manager->register(new \Fallimo_Elementor_Services_Widget());
        $widgets_manager->register(new \Fallimo_Elementor_Testimonials_Widget());
        $widgets_manager->register(new \Fallimo_Elementor_Features_Widget());
        $widgets_manager->register(new \Fallimo_Elementor_FAQ_Widget());
        $widgets_manager->register(new \Fallimo_Elementor_Video_Gallery_Widget());
        $widgets_manager->register(new \Fallimo_Elementor_Quote_Form_Widget());
        $widgets_manager->register(new \Fallimo_Elementor_Footer_Widget());
    }
    
    public function enqueue_styles() {
        wp_enqueue_style(
            'fallimo-elementor-widgets',
            FALLIMO_ELEMENTOR_URL . 'assets/css/widgets.css',
            [],
            FALLIMO_ELEMENTOR_VERSION
        );
    }
    
    public function enqueue_scripts() {
        wp_register_script(
            'fallimo-elementor-widgets',
            FALLIMO_ELEMENTOR_URL . 'assets/js/widgets.js',
            ['jquery'],
            FALLIMO_ELEMENTOR_VERSION,
            true
        );
        
        wp_localize_script('fallimo-elementor-widgets', 'fallimoAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_url' => rest_url('fallimo/v1/'),
            'nonce'    => wp_create_nonce('fallimo_nonce'),
        ]);
    }
}

Fallimo_Elementor_Widgets::instance();
