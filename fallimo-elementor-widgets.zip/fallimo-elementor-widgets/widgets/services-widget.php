<?php
if (!defined('ABSPATH')) exit;

class Fallimo_Elementor_Services_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'fallimo_services';
    }
    
    public function get_title() {
        return __('Fallimo Services', 'fallimo-elementor');
    }
    
    public function get_icon() {
        return 'eicon-posts-grid';
    }
    
    public function get_categories() {
        return ['fallimo'];
    }
    
    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Services', 'fallimo-elementor'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'section_title',
            [
                'label' => __('Section Title', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Our Services', 'fallimo-elementor'),
            ]
        );
        
        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control(
            'service_icon',
            [
                'label' => __('Icon', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'solid',
                ],
            ]
        );
        
        $repeater->add_control(
            'service_title',
            [
                'label' => __('Title', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Service Name', 'fallimo-elementor'),
            ]
        );
        
        $repeater->add_control(
            'service_description',
            [
                'label' => __('Description', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Service description goes here.', 'fallimo-elementor'),
            ]
        );
        
        $this->add_control(
            'services',
            [
                'label' => __('Services', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'service_title' => __('Wedding Transportation', 'fallimo-elementor'),
                        'service_description' => __('Make your special day perfect with our luxury wedding transportation.', 'fallimo-elementor'),
                    ],
                ],
                'title_field' => '{{{ service_title }}}',
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="fallimo-services py-20" id="services">
            <div class="container mx-auto px-4">
                <?php if (!empty($settings['section_title'])) : ?>
                    <h2 class="text-4xl font-bold text-center mb-12"><?php echo esc_html($settings['section_title']); ?></h2>
                <?php endif; ?>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php foreach ($settings['services'] as $service) : ?>
                        <div class="text-center p-6 bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow fade-in">
                            <div class="flex justify-center mb-4 text-primary text-5xl">
                                <?php \Elementor\Icons_Manager::render_icon($service['service_icon'], ['aria-hidden' => 'true']); ?>
                            </div>
                            <h3 class="text-xl font-semibold mb-3"><?php echo esc_html($service['service_title']); ?></h3>
                            <p class="text-gray-600"><?php echo esc_html($service['service_description']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
    }
}
