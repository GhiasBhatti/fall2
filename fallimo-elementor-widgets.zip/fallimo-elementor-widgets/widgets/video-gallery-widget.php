<?php
if (!defined('ABSPATH')) exit;

class Fallimo_Elementor_Video_Gallery_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'fallimo_video_gallery'; }
    public function get_title() { return __('Fallimo Video Gallery', 'fallimo-elementor'); }
    public function get_icon() { return 'eicon-video-playlist'; }
    public function get_categories() { return ['fallimo']; }
    
    protected function register_controls() {
        $this->start_controls_section('content_section', ['label' => __('Videos', 'fallimo-elementor'), 'tab' => \Elementor\Controls_Manager::TAB_CONTENT]);
        $this->add_control('section_title', ['label' => __('Section Title', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => __('Video Gallery', 'fallimo-elementor')]);
        $repeater = new \Elementor\Repeater();
        $repeater->add_control('video_url', ['label' => __('Video URL (YouTube/Vimeo)', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'https://www.youtube.com/watch?v=dQw4w9WgXcQ']);
        $repeater->add_control('video_title', ['label' => __('Title', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => __('Video Title', 'fallimo-elementor')]);
        $this->add_control('videos', ['label' => __('Videos', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $repeater->get_controls(), 'title_field' => '{{{ video_title }}}']);
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="fallimo-video-gallery py-20">
            <div class="container mx-auto px-4">
                <?php if (!empty($settings['section_title'])) : ?><h2 class="text-4xl font-bold text-center mb-12"><?php echo esc_html($settings['section_title']); ?></h2><?php endif; ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php foreach ($settings['videos'] as $video) : ?>
                        <div class="rounded-lg overflow-hidden shadow-lg">
                            <div class="relative pb-[56.25%]">
                                <iframe class="absolute inset-0 w-full h-full" src="<?php echo esc_url(str_replace('watch?v=', 'embed/', $video['video_url'])); ?>" frameborder="0" allowfullscreen></iframe>
                            </div>
                            <?php if (!empty($video['video_title'])) : ?><div class="p-4 bg-white"><h3 class="font-semibold"><?php echo esc_html($video['video_title']); ?></h3></div><?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
    }
}
