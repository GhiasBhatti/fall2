<?php
if (!defined('ABSPATH')) exit;

class Fallimo_Elementor_Quote_Form_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'fallimo_quote_form';
    }
    
    public function get_title() {
        return __('Fallimo Quote Form', 'fallimo-elementor');
    }
    
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    
    public function get_categories() {
        return ['fallimo'];
    }
    
    public function get_script_depends() {
        return ['fallimo-elementor-widgets'];
    }
    
    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Form Settings', 'fallimo-elementor'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'form_title',
            [
                'label' => __('Form Title', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Request a Quote', 'fallimo-elementor'),
            ]
        );
        
        $this->add_control(
            'form_subtitle',
            [
                'label' => __('Subtitle', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Fill out the form below and we\'ll get back to you shortly.', 'fallimo-elementor'),
            ]
        );
        
        $this->add_control(
            'success_message',
            [
                'label' => __('Success Message', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Thank you! Your quote request has been submitted successfully.', 'fallimo-elementor'),
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="fallimo-quote-form py-20" id="quote">
            <div class="container mx-auto px-4 max-w-3xl">
                <?php if (!empty($settings['form_title'])) : ?>
                    <h2 class="text-4xl font-bold text-center mb-4"><?php echo esc_html($settings['form_title']); ?></h2>
                <?php endif; ?>
                
                <?php if (!empty($settings['form_subtitle'])) : ?>
                    <p class="text-center text-gray-600 mb-8"><?php echo esc_html($settings['form_subtitle']); ?></p>
                <?php endif; ?>
                
                <form class="fallimo-quote-form-element bg-white p-8 rounded-lg shadow-lg" data-success-message="<?php echo esc_attr($settings['success_message']); ?>">
                    <?php wp_nonce_field('fallimo_quote_form', 'fallimo_quote_nonce'); ?>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <div>
                            <label class="block text-sm font-semibold mb-2">Name *</label>
                            <input type="text" name="name" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-primary">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-semibold mb-2">Email *</label>
                            <input type="email" name="email" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-primary">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-semibold mb-2">Phone *</label>
                            <input type="tel" name="phone" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-primary">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-semibold mb-2">Event Date *</label>
                            <input type="date" name="eventDate" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-primary">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-semibold mb-2">Event Type</label>
                            <select name="eventType" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-primary">
                                <option value="">Select Event Type</option>
                                <option value="Wedding">Wedding</option>
                                <option value="Birthday">Birthday</option>
                                <option value="Corporate">Corporate Event</option>
                                <option value="Prom">Prom</option>
                                <option value="Night Out">Night Out</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-semibold mb-2">Vehicle Type</label>
                            <select name="vehicleType" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-primary">
                                <option value="">Select Vehicle Type</option>
                                <option value="Party Bus">Party Bus</option>
                                <option value="Limousine">Limousine</option>
                                <option value="SUV">SUV</option>
                                <option value="Sedan">Sedan</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-semibold mb-2">Number of Passengers</label>
                            <input type="number" name="passengers" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-primary">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-semibold mb-2">Duration</label>
                            <select name="duration" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-primary">
                                <option value="">Select Duration</option>
                                <option value="2-4 hours">2-4 hours</option>
                                <option value="4-6 hours">4-6 hours</option>
                                <option value="6-8 hours">6-8 hours</option>
                                <option value="8+ hours">8+ hours</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-semibold mb-2">Pickup Location</label>
                            <input type="text" name="pickupLocation" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-primary">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-semibold mb-2">Destination</label>
                            <input type="text" name="destination" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-primary">
                        </div>
                    </div>
                    
                    <div class="mb-6">
                        <label class="block text-sm font-semibold mb-2">Additional Message</label>
                        <textarea name="message" rows="4" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-primary"></textarea>
                    </div>
                    
                    <div class="text-center">
                        <button type="submit" class="btn-primary px-12 py-3">Submit Quote Request</button>
                    </div>
                    
                    <div class="fallimo-quote-message mt-4 hidden"></div>
                </form>
            </div>
        </section>
        <?php
    }
}
