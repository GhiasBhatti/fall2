<?php
if (!defined('ABSPATH')) exit;

class Fallimo_Elementor_Features_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'fallimo_features'; }
    public function get_title() { return __('Fallimo Features', 'fallimo-elementor'); }
    public function get_icon() { return 'eicon-bullet-list'; }
    public function get_categories() { return ['fallimo']; }
    
    protected function register_controls() {
        $this->start_controls_section('content_section', ['label' => __('Features', 'fallimo-elementor'), 'tab' => \Elementor\Controls_Manager::TAB_CONTENT]);
        $this->add_control('section_title', ['label' => __('Section Title', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => __('Features', 'fallimo-elementor')]);
        $repeater = new \Elementor\Repeater();
        $repeater->add_control('feature_icon', ['label' => __('Icon', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::ICONS, 'default' => ['value' => 'fas fa-check', 'library' => 'solid']]);
        $repeater->add_control('feature_title', ['label' => __('Title', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => __('Feature', 'fallimo-elementor')]);
        $repeater->add_control('feature_description', ['label' => __('Description', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::TEXTAREA, 'default' => __('Description', 'fallimo-elementor')]);
        $this->add_control('features', ['label' => __('Features', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $repeater->get_controls(), 'title_field' => '{{{ feature_title }}}']);
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="fallimo-features py-20">
            <div class="container mx-auto px-4">
                <?php if (!empty($settings['section_title'])) : ?><h2 class="text-4xl font-bold text-center mb-12"><?php echo esc_html($settings['section_title']); ?></h2><?php endif; ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php foreach ($settings['features'] as $feature) : ?>
                        <div class="flex items-start space-x-4 fade-in">
                            <div class="text-primary text-3xl flex-shrink-0"><?php \Elementor\Icons_Manager::render_icon($feature['feature_icon'], ['aria-hidden' => 'true']); ?></div>
                            <div><h3 class="text-xl font-semibold mb-2"><?php echo esc_html($feature['feature_title']); ?></h3><p class="text-gray-600"><?php echo esc_html($feature['feature_description']); ?></p></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
    }
}
