<?php
if (!defined('ABSPATH')) exit;

class Fallimo_Elementor_FAQ_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'fallimo_faq'; }
    public function get_title() { return __('Fallimo FAQ', 'fallimo-elementor'); }
    public function get_icon() { return 'eicon-accordion'; }
    public function get_categories() { return ['fallimo']; }
    
    protected function register_controls() {
        $this->start_controls_section('content_section', ['label' => __('FAQ', 'fallimo-elementor'), 'tab' => \Elementor\Controls_Manager::TAB_CONTENT]);
        $this->add_control('section_title', ['label' => __('Section Title', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => __('Frequently Asked Questions', 'fallimo-elementor')]);
        $repeater = new \Elementor\Repeater();
        $repeater->add_control('question', ['label' => __('Question', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => __('Question?', 'fallimo-elementor')]);
        $repeater->add_control('answer', ['label' => __('Answer', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::TEXTAREA, 'default' => __('Answer text', 'fallimo-elementor')]);
        $this->add_control('faqs', ['label' => __('FAQs', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $repeater->get_controls(), 'title_field' => '{{{ question }}}']);
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="fallimo-faq py-20 bg-light-gray">
            <div class="container mx-auto px-4 max-w-3xl">
                <?php if (!empty($settings['section_title'])) : ?><h2 class="text-4xl font-bold text-center mb-12"><?php echo esc_html($settings['section_title']); ?></h2><?php endif; ?>
                <div class="space-y-4">
                    <?php foreach ($settings['faqs'] as $index => $faq) : ?>
                        <div class="bg-white rounded-lg shadow-md">
                            <button class="w-full text-left p-6 font-semibold flex justify-between items-center faq-toggle" data-target="faq-<?php echo $index; ?>">
                                <?php echo esc_html($faq['question']); ?><span class="text-2xl">+</span>
                            </button>
                            <div id="faq-<?php echo $index; ?>" class="faq-answer hidden p-6 pt-0 text-gray-600"><?php echo esc_html($faq['answer']); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
    }
}
