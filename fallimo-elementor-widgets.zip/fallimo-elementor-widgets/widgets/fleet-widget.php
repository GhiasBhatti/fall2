<?php
if (!defined('ABSPATH')) exit;

class Fallimo_Elementor_Fleet_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'fallimo_fleet';
    }
    
    public function get_title() {
        return __('Fallimo Fleet', 'fallimo-elementor');
    }
    
    public function get_icon() {
        return 'eicon-gallery-grid';
    }
    
    public function get_categories() {
        return ['fallimo'];
    }
    
    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Fleet Vehicles', 'fallimo-elementor'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'section_title',
            [
                'label' => __('Section Title', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Our Premium Fleet', 'fallimo-elementor'),
            ]
        );
        
        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control(
            'vehicle_title',
            [
                'label' => __('Vehicle Name', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Luxury Limousine', 'fallimo-elementor'),
            ]
        );
        
        $repeater->add_control(
            'vehicle_description',
            [
                'label' => __('Description', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Experience luxury transportation at its finest.', 'fallimo-elementor'),
            ]
        );
        
        $repeater->add_control(
            'vehicle_image',
            [
                'label' => __('Image', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        
        $repeater->add_control(
            'vehicle_capacity',
            [
                'label' => __('Capacity', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Up to 10 passengers', 'fallimo-elementor'),
            ]
        );
        
        $repeater->add_control(
            'vehicle_price',
            [
                'label' => __('Price (optional)', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('From $299', 'fallimo-elementor'),
            ]
        );
        
        $repeater->add_control(
            'vehicle_features',
            [
                'label' => __('Features (one per line)', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => "WiFi\nPremium Sound System\nLuxury Bar",
            ]
        );
        
        $this->add_control(
            'vehicles',
            [
                'label' => __('Vehicles', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'vehicle_title' => __('Luxury Limousine', 'fallimo-elementor'),
                        'vehicle_capacity' => __('Up to 10 passengers', 'fallimo-elementor'),
                    ],
                ],
                'title_field' => '{{{ vehicle_title }}}',
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="fallimo-fleet py-20 bg-light-gray" id="fleet">
            <div class="container mx-auto px-4">
                <?php if (!empty($settings['section_title'])) : ?>
                    <h2 class="text-4xl font-bold text-center mb-12"><?php echo esc_html($settings['section_title']); ?></h2>
                <?php endif; ?>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php foreach ($settings['vehicles'] as $vehicle) : ?>
                        <div class="fallimo-fleet-card bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow scale-in">
                            <div class="relative">
                                <img src="<?php echo esc_url($vehicle['vehicle_image']['url']); ?>" alt="<?php echo esc_attr($vehicle['vehicle_title']); ?>" class="w-full h-64 object-cover">
                                <div class="absolute top-4 left-4 bg-white/90 px-3 py-1 rounded-full text-sm font-semibold">
                                    <?php echo esc_html($vehicle['vehicle_capacity']); ?>
                                </div>
                                <?php if (!empty($vehicle['vehicle_price'])) : ?>
                                    <div class="absolute top-4 right-4 bg-primary text-white px-3 py-1 rounded-full text-sm font-semibold">
                                        <?php echo esc_html($vehicle['vehicle_price']); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="p-6">
                                <h3 class="text-xl font-semibold mb-2"><?php echo esc_html($vehicle['vehicle_title']); ?></h3>
                                <p class="text-gray-600 mb-4"><?php echo esc_html($vehicle['vehicle_description']); ?></p>
                                
                                <?php if (!empty($vehicle['vehicle_features'])) : 
                                    $features = array_filter(array_map('trim', explode("\n", $vehicle['vehicle_features'])));
                                    if (!empty($features)) :
                                ?>
                                    <div class="flex flex-wrap gap-2 mb-6">
                                        <?php foreach ($features as $feature) : ?>
                                            <span class="text-sm text-gray-600"><?php echo esc_html($feature); ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; endif; ?>
                                
                                <div class="flex gap-2">
                                    <a href="#quote" class="flex-1 btn-secondary text-center py-2">View Details</a>
                                    <a href="#quote" class="flex-1 btn-primary text-center py-2">Book Now</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
    }
}
