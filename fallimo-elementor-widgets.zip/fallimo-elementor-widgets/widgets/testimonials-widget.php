<?php
if (!defined('ABSPATH')) exit;

class Fallimo_Elementor_Testimonials_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'fallimo_testimonials';
    }
    
    public function get_title() {
        return __('Fallimo Testimonials', 'fallimo-elementor');
    }
    
    public function get_icon() {
        return 'eicon-testimonial';
    }
    
    public function get_categories() {
        return ['fallimo'];
    }
    
    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Testimonials', 'fallimo-elementor'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'section_title',
            [
                'label' => __('Section Title', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('What Our Clients Say', 'fallimo-elementor'),
            ]
        );
        
        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control(
            'client_name',
            [
                'label' => __('Client Name', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('John Doe', 'fallimo-elementor'),
            ]
        );
        
        $repeater->add_control(
            'client_rating',
            [
                'label' => __('Rating', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 5,
                'min' => 1,
                'max' => 5,
            ]
        );
        
        $repeater->add_control(
            'testimonial_text',
            [
                'label' => __('Testimonial', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Amazing service!', 'fallimo-elementor'),
            ]
        );
        
        $this->add_control(
            'testimonials',
            [
                'label' => __('Testimonials', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'client_name' => __('John Doe', 'fallimo-elementor'),
                        'client_rating' => 5,
                        'testimonial_text' => __('Excellent service! Highly recommended.', 'fallimo-elementor'),
                    ],
                ],
                'title_field' => '{{{ client_name }}}',
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="fallimo-testimonials py-20 bg-light-gray" id="testimonials">
            <div class="container mx-auto px-4">
                <?php if (!empty($settings['section_title'])) : ?>
                    <h2 class="text-4xl font-bold text-center mb-12"><?php echo esc_html($settings['section_title']); ?></h2>
                <?php endif; ?>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php foreach ($settings['testimonials'] as $testimonial) : ?>
                        <div class="bg-white p-6 rounded-lg shadow-md fade-in">
                            <div class="flex mb-4">
                                <?php for ($i = 0; $i < 5; $i++) : ?>
                                    <span class="text-2xl <?php echo $i < $testimonial['client_rating'] ? 'text-yellow-400' : 'text-gray-300'; ?>">★</span>
                                <?php endfor; ?>
                            </div>
                            <p class="text-gray-700 mb-4 italic">"<?php echo esc_html($testimonial['testimonial_text']); ?>"</p>
                            <p class="font-semibold"><?php echo esc_html($testimonial['client_name']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
    }
}
