<?php
if (!defined('ABSPATH')) exit;

class Fallimo_Elementor_Footer_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'fallimo_footer'; }
    public function get_title() { return __('Fallimo Footer', 'fallimo-elementor'); }
    public function get_icon() { return 'eicon-footer'; }
    public function get_categories() { return ['fallimo']; }
    
    protected function register_controls() {
        $this->start_controls_section('content_section', ['label' => __('Footer', 'fallimo-elementor'), 'tab' => \Elementor\Controls_Manager::TAB_CONTENT]);
        $this->add_control('logo', ['label' => __('Logo', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::MEDIA, 'default' => ['url' => \Elementor\Utils::get_placeholder_image_src()]]);
        $this->add_control('description', ['label' => __('Description', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::TEXTAREA, 'default' => __('Luxury transportation services', 'fallimo-elementor')]);
        $this->add_control('copyright', ['label' => __('Copyright Text', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => __('© 2024 Fallimo. All rights reserved.', 'fallimo-elementor')]);
        $repeater = new \Elementor\Repeater();
        $repeater->add_control('link_text', ['label' => __('Text', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => __('Link', 'fallimo-elementor')]);
        $repeater->add_control('link_url', ['label' => __('URL', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => '#']);
        $this->add_control('footer_links', ['label' => __('Footer Links', 'fallimo-elementor'), 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $repeater->get_controls(), 'title_field' => '{{{ link_text }}}']);
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <footer class="fallimo-footer bg-dark text-white py-12">
            <div class="container mx-auto px-4">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                    <div><?php if (!empty($settings['logo']['url'])) : ?><img src="<?php echo esc_url($settings['logo']['url']); ?>" alt="Logo" class="h-12 mb-4"><?php endif; ?><p class="text-white/80"><?php echo esc_html($settings['description']); ?></p></div>
                    <div><h3 class="text-xl font-semibold mb-4">Quick Links</h3><ul class="space-y-2"><?php foreach ($settings['footer_links'] as $link) : ?><li><a href="<?php echo esc_url($link['link_url']); ?>" class="text-white/80 hover:text-white"><?php echo esc_html($link['link_text']); ?></a></li><?php endforeach; ?></ul></div>
                    <div><h3 class="text-xl font-semibold mb-4">Contact</h3><p class="text-white/80">Contact information can be added here</p></div>
                </div>
                <div class="border-t border-white/20 pt-8 text-center text-white/60"><?php echo esc_html($settings['copyright']); ?></div>
            </div>
        </footer>
        <?php
    }
}
