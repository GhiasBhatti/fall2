<?php
if (!defined('ABSPATH')) exit;

class Fallimo_Elementor_Hero_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'fallimo_hero';
    }
    
    public function get_title() {
        return __('Fallimo Hero', 'fallimo-elementor');
    }
    
    public function get_icon() {
        return 'eicon-slider-push';
    }
    
    public function get_categories() {
        return ['fallimo'];
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'fallimo-elementor'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'background_image',
            [
                'label' => __('Background Image', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        
        $this->add_control(
            'title',
            [
                'label' => __('Title', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Number #1 Party Bus and Limo Service', 'fallimo-elementor'),
                'label_block' => true,
            ]
        );
        
        $this->add_control(
            'subtitle',
            [
                'label' => __('Subtitle', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Choose the Best, Leave the Rest!', 'fallimo-elementor'),
                'label_block' => true,
            ]
        );
        
        $this->add_control(
            'description',
            [
                'label' => __('Description', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Make your Event Unforgettable with our Top-Rated Service.', 'fallimo-elementor'),
                'rows' => 3,
            ]
        );
        
        $this->end_controls_section();
        
        // Stats Section
        $this->start_controls_section(
            'stats_section',
            [
                'label' => __('Stats', 'fallimo-elementor'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control(
            'stat_icon',
            [
                'label' => __('Icon', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'solid',
                ],
            ]
        );
        
        $repeater->add_control(
            'stat_value',
            [
                'label' => __('Value', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('4.8', 'fallimo-elementor'),
            ]
        );
        
        $repeater->add_control(
            'stat_label',
            [
                'label' => __('Label', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Star Rating', 'fallimo-elementor'),
            ]
        );
        
        $repeater->add_control(
            'stat_color',
            [
                'label' => __('Icon Color', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#fcfa7e',
            ]
        );
        
        $this->add_control(
            'stats',
            [
                'label' => __('Stats', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'stat_value' => '4.8',
                        'stat_label' => 'Star Rating',
                        'stat_color' => '#fcfa7e',
                    ],
                    [
                        'stat_value' => '2-55',
                        'stat_label' => 'Passengers',
                        'stat_color' => '#767bf5',
                    ],
                    [
                        'stat_value' => '24/7',
                        'stat_label' => 'Available',
                        'stat_color' => '#77f073',
                    ],
                    [
                        'stat_value' => '$100-300',
                        'stat_label' => 'Cashback',
                        'stat_color' => '#f77c7c',
                    ],
                ],
                'title_field' => '{{{ stat_label }}}',
            ]
        );
        
        $this->end_controls_section();
        
        // CTA Section
        $this->start_controls_section(
            'cta_section',
            [
                'label' => __('Call to Action', 'fallimo-elementor'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'primary_button_text',
            [
                'label' => __('Primary Button Text', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Get Free Quote', 'fallimo-elementor'),
            ]
        );
        
        $this->add_control(
            'primary_button_link',
            [
                'label' => __('Primary Button Link', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '#quote',
            ]
        );
        
        $this->add_control(
            'secondary_button_text',
            [
                'label' => __('Secondary Button Text', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('View Fleet', 'fallimo-elementor'),
            ]
        );
        
        $this->add_control(
            'secondary_button_link',
            [
                'label' => __('Secondary Button Link', 'fallimo-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '#fleet',
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="fallimo-hero relative min-h-screen flex items-center fade-in" id="home">
            <div class="absolute inset-0">
                <?php if (!empty($settings['background_image']['url'])) : ?>
                    <img src="<?php echo esc_url($settings['background_image']['url']); ?>" alt="<?php echo esc_attr($settings['title']); ?>" class="w-full h-full object-cover">
                <?php endif; ?>
                <div class="absolute inset-0 bg-black/50"></div>
            </div>
            
            <div class="relative container mx-auto px-4 lg:px-8 z-10">
                <div class="max-w-3xl">
                    <?php if (!empty($settings['title'])) : ?>
                        <h1 class="text-4xl md:text-6xl font-bold mb-6 text-white">
                            <?php echo esc_html($settings['title']); ?>
                        </h1>
                    <?php endif; ?>
                    
                    <?php if (!empty($settings['subtitle'])) : ?>
                        <div class="text-2xl md:text-3xl font-semibold mb-6 text-white">
                            <?php echo esc_html($settings['subtitle']); ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($settings['description'])) : ?>
                        <p class="text-xl text-white/90 mb-8 leading-relaxed">
                            <?php echo esc_html($settings['description']); ?>
                        </p>
                    <?php endif; ?>
                    
                    <?php if (!empty($settings['stats'])) : ?>
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
                            <?php foreach ($settings['stats'] as $stat) : ?>
                                <div class="text-center">
                                    <div class="flex items-center justify-center mb-2" style="color: <?php echo esc_attr($stat['stat_color']); ?>">
                                        <?php \Elementor\Icons_Manager::render_icon($stat['stat_icon'], ['aria-hidden' => 'true', 'class' => 'w-6 h-6']); ?>
                                    </div>
                                    <div class="text-2xl font-bold text-white"><?php echo esc_html($stat['stat_value']); ?></div>
                                    <div class="text-sm text-white/80"><?php echo esc_html($stat['stat_label']); ?></div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="flex flex-col sm:flex-row gap-4">
                        <?php if (!empty($settings['primary_button_text'])) : ?>
                            <a href="<?php echo esc_url($settings['primary_button_link']); ?>" class="btn-primary text-center">
                                <?php echo esc_html($settings['primary_button_text']); ?>
                            </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($settings['secondary_button_text'])) : ?>
                            <a href="<?php echo esc_url($settings['secondary_button_link']); ?>" class="btn-secondary text-center">
                                <?php echo esc_html($settings['secondary_button_text']); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
        <?php
    }
}
